#ifndef COOLBOX__LIBRARIES_PYTHON_BINDINGS_INCLUDE_GRAPHICS_CHARTS_HEADERS_GRAPHICS_H
#define COOLBOX__LIBRARIES_PYTHON_BINDINGS_INCLUDE_GRAPHICS_CHARTS_HEADERS_GRAPHICS_H

#include <cstdint>
#include <string>
#include <vector>
#include <stdexcept>

namespace graphics {

// ===================================================================
// Color
// ===================================================================

struct Color {
    uint8_t r = 0, g = 0, b = 0, a = 255;

    bool operator==(const Color& o) const {
        return r == o.r && g == o.g && b == o.b && a == o.a;
    }
    bool operator!=(const Color& o) const { return !(*this == o); }
};

namespace Colors {
    inline constexpr Color Black   {  0,   0,   0, 255};
    inline constexpr Color White   {255, 255, 255, 255};
    inline constexpr Color Red     {220,  50,  50, 255};
    inline constexpr Color Green   { 50, 180,  50, 255};
    inline constexpr Color Blue    { 50,  90, 220, 255};
    inline constexpr Color Orange  {230, 150,  30, 255};
    inline constexpr Color Purple  {150,  50, 200, 255};
    inline constexpr Color Cyan    { 50, 200, 200, 255};
    inline constexpr Color Gray    {180, 180, 180, 255};
    inline constexpr Color DarkGray{100, 100, 100, 255};
    inline constexpr Color LightGray{230, 230, 230, 255};
}

// ===================================================================
// Canvas – pixel buffer with drawing primitives
// ===================================================================

class Canvas {
public:
    Canvas(int width, int height, Color bg = Colors::White);

    // Accessors
    int width()  const { return width_; }
    int height() const { return height_; }
    const uint8_t* data() const { return pixels_.data(); }

    // Pixel operations
    void set_pixel(int x, int y, Color c);
    Color get_pixel(int x, int y) const;
    void fill(Color c);

    // Drawing primitives
    void draw_line(int x0, int y0, int x1, int y1, Color c, int thickness = 1);
    void draw_rect(int x, int y, int w, int h, Color c, bool filled = false);
    void draw_circle(int cx, int cy, int radius, Color c, bool filled = false);

    // Polygon / plane drawing (kept minimal for bindings header)
    enum class FillStyle { Solid, VerticalGradient, Hatch };
    void draw_polygon(const std::vector<std::pair<int,int>>& pts,
                      Color outline,
                      bool filled = false,
                      FillStyle style = FillStyle::Solid,
                      Color fill_color = Colors::LightGray,
                      Color fill_color2 = Colors::White,
                      int hatch_spacing = 6);

    /** Draw a string using a built-in 5×7 bitmap font. Scale multiplies size. */
    void draw_text(int x, int y, const std::string& text, Color c, int scale = 1);

    // Export
    bool save_bmp(const std::string& path) const;
    bool save_png(const std::string& path) const;
    bool save_jpg(const std::string& path, int quality = 90) const;

private:
    int width_, height_;
    std::vector<uint8_t> pixels_;   // RGBA, row-major, top-left origin

    void blend_pixel(int x, int y, Color c);
};

// ===================================================================
// Graph
// ===================================================================

enum class GraphType { Line, Bar, Scatter };

struct DataSeries {
    std::string label;
    std::vector<double> x_values;
    std::vector<double> y_values;
    Color color = Colors::Blue;
};

class Graph {
public:
    explicit Graph(int width = 800, int height = 600,
                   GraphType type = GraphType::Line);

    void set_title(const std::string& title);
    void set_x_label(const std::string& label);
    void set_y_label(const std::string& label);
    void set_type(GraphType type);
    void add_series(const DataSeries& series);

    /** Render the graph and return the resulting canvas. */
    Canvas render() const;

private:
    int width_, height_;
    GraphType type_;
    std::string title_;
    std::string x_label_, y_label_;
    std::vector<DataSeries> series_;

    // Internal layout
    struct PlotArea { int x, y, w, h; };
    PlotArea compute_plot_area() const;

    void draw_axes(Canvas& canvas, const PlotArea& area,
                   double x_min, double x_max,
                   double y_min, double y_max) const;
    void draw_line_series(Canvas& canvas, const PlotArea& area,
                          const DataSeries& s,
                          double x_min, double x_max,
                          double y_min, double y_max) const;
    void draw_bar_series(Canvas& canvas, const PlotArea& area,
                         int series_idx, int total_series,
                         const DataSeries& s,
                         double x_min, double x_max,
                         double y_min, double y_max) const;
    void draw_scatter_series(Canvas& canvas, const PlotArea& area,
                             const DataSeries& s,
                             double x_min, double x_max,
                             double y_min, double y_max) const;
    void draw_legend(Canvas& canvas, const PlotArea& area) const;
};

// ===================================================================
// Table
// ===================================================================

class Table {
public:
    Table();

    void set_headers(const std::vector<std::string>& headers);
    void add_row(const std::vector<std::string>& row);

    void set_cell_padding(int px);
    void set_font_scale(int scale);
    void set_header_color(Color c);
    void set_border_color(Color c);
    void set_alternate_row_color(Color c);

    /** Render the table and return the resulting canvas. */
    Canvas render() const;

private:
    std::vector<std::string> headers_;
    std::vector<std::vector<std::string>> rows_;
    int cell_padding_ = 8;
    int font_scale_ = 1;
    Color header_bg_    = {70, 130, 200, 255};
    Color header_fg_    = Colors::White;
    Color border_color_ = Colors::Gray;
    Color alt_row_color_= {245, 245, 255, 255};

    int compute_col_width(int col) const;
};

} // namespace graphics
#endif  // COOLBOX__LIBRARIES_PYTHON_BINDINGS_INCLUDE_GRAPHICS_CHARTS_HEADERS_GRAPHICS_H
