
module hdmi_qsys (
	alt_vip_cl_cvo_0_clocked_video_vid_data,
	alt_vip_cl_cvo_0_clocked_video_underflow,
	alt_vip_cl_cvo_0_clocked_video_vid_datavalid,
	alt_vip_cl_cvo_0_clocked_video_vid_v_sync,
	alt_vip_cl_cvo_0_clocked_video_vid_h_sync,
	alt_vip_cl_cvo_0_clocked_video_vid_f,
	alt_vip_cl_cvo_0_clocked_video_vid_h,
	alt_vip_cl_cvo_0_clocked_video_vid_v,
	altpll_0_locked_conduit_export,
	clk_clk,
	disp_refclk_out_clk_clk,
	hdmi_tx_int_n_external_connection_export,
	opencores_i2c_0_export_0_scl_pad_io,
	opencores_i2c_0_export_0_sda_pad_io,
	reset_reset_n);	

	output	[23:0]	alt_vip_cl_cvo_0_clocked_video_vid_data;
	output		alt_vip_cl_cvo_0_clocked_video_underflow;
	output		alt_vip_cl_cvo_0_clocked_video_vid_datavalid;
	output		alt_vip_cl_cvo_0_clocked_video_vid_v_sync;
	output		alt_vip_cl_cvo_0_clocked_video_vid_h_sync;
	output		alt_vip_cl_cvo_0_clocked_video_vid_f;
	output		alt_vip_cl_cvo_0_clocked_video_vid_h;
	output		alt_vip_cl_cvo_0_clocked_video_vid_v;
	output		altpll_0_locked_conduit_export;
	input		clk_clk;
	output		disp_refclk_out_clk_clk;
	input		hdmi_tx_int_n_external_connection_export;
	inout		opencores_i2c_0_export_0_scl_pad_io;
	inout		opencores_i2c_0_export_0_sda_pad_io;
	input		reset_reset_n;
endmodule
