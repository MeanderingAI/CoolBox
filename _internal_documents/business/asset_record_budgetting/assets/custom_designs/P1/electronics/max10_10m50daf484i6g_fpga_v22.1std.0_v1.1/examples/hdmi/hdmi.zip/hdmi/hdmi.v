/*******************************************************************************
*
* Copyright (C) 2018-2024 Intel Corporation
* 
* This code and the related documents are Intel copyrighted materials, and 
* your use of them is governed by the express license under which they were 
* provided to you ("License"). Unless the License provides otherwise, you may 
* not use, modify, copy, publish, distribute, disclose or transmit this 
* code or the related documents without Intel's prior written permission.
*
* This code and the related documents are provided as is, with no express 
* or implied warranties, other than those that are expressly stated in the 
* License.
*
*******************************************************************************/

module hdmi(

    //////////// RESET //////////
    input  wire        fpga_resetn,
    
    //////////// CLOCK //////////
    input  wire        clk_ddr3_100_p,
    input  wire        clk_50_max10,
    input  wire        clk_25_max10,
    input  wire        clk_10_adc,
    input  wire        clk_lvds_125_p,
    
    //////////// PUSH BUTTON //////////
    input  wire  [3:0] user_pb,
    
    //////////// LED //////////
    output wire  [4:0] user_led,
    
    //////////// DIP SWITCH //////////
    input  wire  [4:0] user_dipsw,
 
    //////////// HDMI TX //////////
    output wire        hdmi_tx_clk,
    output wire [23:0] hdmi_tx_d,
    output wire        hdmi_tx_hs,
    output wire        hdmi_tx_vs,
    output wire        hdmi_tx_de,
    input  wire        hdmi_tx_int,
    inout  wire        hdmi_sda,
    output wire        hdmi_scl
    );


//=======================================================
//  REG/WIRE declarations
//=======================================================
wire         pll_lock;
reg   [25:0] heart_beat_cnt;

//=======================================================
//  Structural coding
//=======================================================
hdmi_qsys   u_hdmi_qsys (
            .clk_clk                                      (clk_50_max10), //                                 clk.clk
            .reset_reset_n                                (fpga_resetn ), //                               reset.reset_n
            .disp_refclk_out_clk_clk                      (hdmi_tx_clk ), //                 disp_refclk_out_clk.clk
            .altpll_0_locked_conduit_export               (pll_lock    ), //             altpll_0_locked_conduit.export
            .alt_vip_cl_cvo_0_clocked_video_vid_data      (hdmi_tx_d   ), //      alt_vip_cl_cvo_0_clocked_video.vid_data
            //.alt_vip_cl_cvo_0_clocked_video_underflow   (            ), //                                    .underflow
            .alt_vip_cl_cvo_0_clocked_video_vid_datavalid (hdmi_tx_de  ), //                                    .vid_datavalid
            .alt_vip_cl_cvo_0_clocked_video_vid_v_sync    (hdmi_tx_vs  ), //                                    .vid_v_sync
            .alt_vip_cl_cvo_0_clocked_video_vid_h_sync    (hdmi_tx_hs  ), //                                    .vid_h_sync
            //.alt_vip_cl_cvo_0_clocked_video_vid_f       (            ), //                                    .vid_f
            //.alt_vip_cl_cvo_0_clocked_video_vid_h       (            ), //                                    .vid_h
            //.alt_vip_cl_cvo_0_clocked_video_vid_v       (            ), //                                    .vid_v
            .opencores_i2c_0_export_0_scl_pad_io          (hdmi_scl    ), //            opencores_i2c_0_export_0.scl_pad_io
            .opencores_i2c_0_export_0_sda_pad_io          (hdmi_sda    ), //                                    .sda_pad_io
            .hdmi_tx_int_n_external_connection_export     (hdmi_tx_int )  //   hdmi_tx_int_n_external_connection.export
            );

//Heart beat by 50MHz clock
always @(posedge clk_50_max10 or negedge fpga_resetn)
  if (!fpga_resetn)
      heart_beat_cnt <= 26'h0; //0x3FFFFFF
  else
      heart_beat_cnt <= heart_beat_cnt + 1'b1;

assign user_led[0] = !pll_lock;
assign user_led[1] = 1'b1;
assign user_led[2] = 1'b1;
assign user_led[3] = 1'b1;
assign user_led[4] = !heart_beat_cnt[25];

endmodule
