	gpio u0 (
		.adc1_out_external_connection_in_port                          (<connected-to-adc1_out_external_connection_in_port>),                          //                 adc1_out_external_connection.in_port
		.adc1_out_external_connection_out_port                         (<connected-to-adc1_out_external_connection_out_port>),                         //                                             .out_port
		.adc2_in_external_connection_export                            (<connected-to-adc2_in_external_connection_export>),                            //                  adc2_in_external_connection.export
		.altpll_0_areset_conduit_export                                (<connected-to-altpll_0_areset_conduit_export>),                                //                      altpll_0_areset_conduit.export
		.altpll_0_locked_conduit_export                                (<connected-to-altpll_0_locked_conduit_export>),                                //                      altpll_0_locked_conduit.export
		.clk_50m_clk                                                   (<connected-to-clk_50m_clk>),                                                   //                                      clk_50m.clk
		.dac_ctrl_external_connection_export                           (<connected-to-dac_ctrl_external_connection_export>),                           //                 dac_ctrl_external_connection.export
		.generic_quad_spi_controller_0_flash_dataout_conduit_dataout   (<connected-to-generic_quad_spi_controller_0_flash_dataout_conduit_dataout>),   //  generic_quad_spi_controller_0_flash_dataout.conduit_dataout
		.generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out (<connected-to-generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out>), // generic_quad_spi_controller_0_flash_dclk_out.conduit_dclk_out
		.generic_quad_spi_controller_0_flash_ncs_conduit_ncs           (<connected-to-generic_quad_spi_controller_0_flash_ncs_conduit_ncs>),           //      generic_quad_spi_controller_0_flash_ncs.conduit_ncs
		.pmod_input_external_connection_export                         (<connected-to-pmod_input_external_connection_export>),                         //               pmod_input_external_connection.export
		.pmod_output_external_connection_in_port                       (<connected-to-pmod_output_external_connection_in_port>),                       //              pmod_output_external_connection.in_port
		.pmod_output_external_connection_out_port                      (<connected-to-pmod_output_external_connection_out_port>),                      //                                             .out_port
		.reset_50m_reset_n                                             (<connected-to-reset_50m_reset_n>),                                             //                                    reset_50m.reset_n
		.uart_0_external_connection_rxd                                (<connected-to-uart_0_external_connection_rxd>),                                //                   uart_0_external_connection.rxd
		.uart_0_external_connection_txd                                (<connected-to-uart_0_external_connection_txd>),                                //                                             .txd
		.usb_debug_master_0_usb_if_clk                                 (<connected-to-usb_debug_master_0_usb_if_clk>),                                 //                    usb_debug_master_0_usb_if.clk
		.usb_debug_master_0_usb_if_reset_n                             (<connected-to-usb_debug_master_0_usb_if_reset_n>),                             //                                             .reset_n
		.usb_debug_master_0_usb_if_full                                (<connected-to-usb_debug_master_0_usb_if_full>),                                //                                             .full
		.usb_debug_master_0_usb_if_empty                               (<connected-to-usb_debug_master_0_usb_if_empty>),                               //                                             .empty
		.usb_debug_master_0_usb_if_wr_n                                (<connected-to-usb_debug_master_0_usb_if_wr_n>),                                //                                             .wr_n
		.usb_debug_master_0_usb_if_rd_n                                (<connected-to-usb_debug_master_0_usb_if_rd_n>),                                //                                             .rd_n
		.usb_debug_master_0_usb_if_oe_n                                (<connected-to-usb_debug_master_0_usb_if_oe_n>),                                //                                             .oe_n
		.usb_debug_master_0_usb_if_data                                (<connected-to-usb_debug_master_0_usb_if_data>),                                //                                             .data
		.usb_debug_master_0_usb_if_addr                                (<connected-to-usb_debug_master_0_usb_if_addr>),                                //                                             .addr
		.usb_debug_master_0_usb_if_scl                                 (<connected-to-usb_debug_master_0_usb_if_scl>),                                 //                                             .scl
		.usb_debug_master_0_usb_if_sda                                 (<connected-to-usb_debug_master_0_usb_if_sda>),                                 //                                             .sda
		.user_dipsw_external_connection_export                         (<connected-to-user_dipsw_external_connection_export>),                         //               user_dipsw_external_connection.export
		.user_led_external_connection_export                           (<connected-to-user_led_external_connection_export>),                           //                 user_led_external_connection.export
		.user_pb_external_connection_export                            (<connected-to-user_pb_external_connection_export>)                             //                  user_pb_external_connection.export
	);

