## Copyright (C) 1991-2014 Altera Corporation. All rights reserved.
## Your use of Altera Corporation's design tools, logic functions 
## and other software and tools, and its AMPP partner logic 
## functions, and any output files from any of the foregoing 
## (including device programming or simulation files), and any 
## associated documentation or information are expressly subject 
## to the terms and conditions of the Altera Program License 
## Subscription Agreement, the Altera Quartus II License Agreement,
## the Altera MegaCore Function License Agreement, or other 
## applicable license agreement, including, without limitation, 
## that your use is for the sole purpose of programming logic 
## devices manufactured by Altera and sold by Altera or its 
## authorized distributors.  Please refer to the applicable 
## agreement for further details.


## VENDOR  "Altera"
## PROGRAM "Quartus II"
## VERSION "Version 14.0.1 Build 203 07/30/2014 SJ Full Version"

## DATE    "Wed Aug 13 15:13:56 2014"

##
## DEVICE  "10M08DAF484C8GES"
##


#**************************************************************
# Time Information
#**************************************************************

set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************
derive_pll_clocks
create_clock -name {altera_reserved_tck} -period 40.800 -waveform { 0.000 20.400 } [get_ports { altera_reserved_tck }]
create_clock -name {clk_50_max10} -period 20.000 -waveform { 0.000 10.000 } [get_ports {clk_50_max10}]
create_clock -name {clk_10_adc} -period 100.000 -waveform { 0.000 50.000 } [get_ports {clk_10_adc}]
create_clock -name {clk_25_max10} -period 40.000 -waveform { 0.000 20.000 } [get_ports {clk_25_max10}]
create_clock -name {clk_lvds_125_p} -period 8.000 -waveform { 0.000 4.000 } [get_ports {clk_lvds_125_p}]
create_clock -name {clk_ddr3_100_p} -period 10.000 -waveform { 0.000 5.000 } [get_ports {clk_ddr3_100_p}]

#**************************************************************
# Create Generated Clock
#**************************************************************

#**************************************************************
# Set Clock Latency
#**************************************************************



#**************************************************************
# Set Clock Uncertainty
#**************************************************************

derive_clock_uncertainty

#**************************************************************
# Set Input Delay
#**************************************************************

set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tdi]
set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tms]


#**************************************************************
# Set Output Delay
#**************************************************************

set_output_delay -clock altera_reserved_tck -clock_fall -max 5 [get_ports altera_reserved_tdo]


#**************************************************************
# Set Clock Groups
#**************************************************************

set_clock_groups -asynchronous -group [get_clocks {altera_reserved_tck}] 

#**************************************************************
# Set False Path
#**************************************************************

set_false_path -from [get_ports {fpga_resetn}] 
set_false_path -from [get_ports {user_dipsw[*]}] 
set_false_path -from [get_ports {user_pb[*]}] 
set_false_path -to [get_ports {user_led[*]}]
set_false_path -to [get_ports {pmodb_io[*]}]

#**************************************************************
# Set Multicycle Path
#**************************************************************



#**************************************************************
# Set Maximum Delay
#**************************************************************


#**************************************************************
# Set Minimum Delay
#**************************************************************



#**************************************************************
# Set Input Transition
#**************************************************************

