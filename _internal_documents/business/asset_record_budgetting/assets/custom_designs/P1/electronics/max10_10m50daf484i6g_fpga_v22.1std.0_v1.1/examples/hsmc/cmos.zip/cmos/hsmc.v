/*******************************************************************************
*
* Copyright (C) 2018-2024 Intel Corporation
* 
* This code and the related documents are Intel copyrighted materials, and 
* your use of them is governed by the express license under which they were 
* provided to you ("License"). Unless the License provides otherwise, you may 
* not use, modify, copy, publish, distribute, disclose or transmit this 
* code or the related documents without Intel's prior written permission.
*
* This code and the related documents are provided as is, with no express 
* or implied warranties, other than those that are expressly stated in the 
* License.
*
*******************************************************************************/

`timescale 1 ps / 1 ps
module hsmc (
		//Reset and Clocks
		input           clk_ddr3_100_p,
		input           clk_50_max10,
		input           clk_25_max10,
		input           clk_lvds_125_p,
		input           clk_10_adc,
		input           fpga_resetn,
		
		//LED PB DIPSW
		output [4:0]    user_led,
		input  [3:0]    user_pb,
		input  [4:0]    user_dipsw,
		
		//HSMC
		input  [2:1]    hsmc_clk_in_p,
		input           hsmc_clk_in0,
		output [2:1]    hsmc_clk_out_p,
		input  [16:0]   hsmc_rx_d_p,
		input  [16:0]   hsmc_rx_d_n,
		output [16:0]   hsmc_tx_d_p,
		output [16:0]   hsmc_tx_d_n
	);

wire            pattern_valid/* synthesis keep */;
wire            pattern_ready/* synthesis keep */;
wire   [39:0]   pattern_out_data/* synthesis keep */;
wire   [39:0]   pattern_in_data/* synthesis keep */;
wire   [5:0]    pattern_loopback;

//CMOS test platform
assign          hsmc_tx_d_p      = pattern_out_data[33:17];
assign          hsmc_tx_d_n      = pattern_out_data[16:0];
assign          pattern_loopback = pattern_out_data[39:34];

assign          pattern_in_data  = {pattern_loopback, 
                                    hsmc_rx_d_p, 
                                    hsmc_rx_d_n
                                    };

hsmc_qsys       hsmc_qsys_u0 (
                        .clk_clk                                      (clk_50_max10    ), //                                      clk.clk
                        .reset_reset_n                                (fpga_resetn     ), //                                    reset.reset_n
                        .user_led_external_connection_export          (user_led        ), //             user_led_external_connection.export
                        .user_pb_external_connection_export           (user_pb         ), //              user_pb_external_connection.export
                        .user_dipsw_external_connection_export        (user_dipsw      ), //           user_dipsw_external_connection.export
                        .data_pattern_generator_0_pattern_out_clk_clk (clk_50_max10    ), // data_pattern_generator_0_pattern_out_clk.clk
                        .data_pattern_generator_0_pattern_out_valid   (pattern_valid   ), //     data_pattern_generator_0_pattern_out.valid
                        .data_pattern_generator_0_pattern_out_ready   (pattern_ready   ), //                                         .ready
                        .data_pattern_generator_0_pattern_out_data    (pattern_out_data), //                                         .data
                        .data_pattern_checker_0_pattern_in_clk_clk    (clk_50_max10    ), //    data_pattern_checker_0_pattern_in_clk.clk
                        .data_pattern_checker_0_pattern_in_valid      (pattern_valid   ), //        data_pattern_checker_0_pattern_in.valid
                        .data_pattern_checker_0_pattern_in_ready      (pattern_ready   ), //                                         .ready
                        .data_pattern_checker_0_pattern_in_data       (pattern_in_data )  //                                         .data
                        );

assign hsmc_clk_out_p = 2'b00;

endmodule
