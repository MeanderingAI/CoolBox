## Copyright (C) 1991-2014 Altera Corporation. All rights reserved.
## Your use of Altera Corporation's design tools, logic functions 
## and other software and tools, and its AMPP partner logic 
## functions, and any output files from any of the foregoing 
## (including device programming or simulation files), and any 
## associated documentation or information are expressly subject 
## to the terms and conditions of the Altera Program License 
## Subscription Agreement, the Altera Quartus II License Agreement,
## the Altera MegaCore Function License Agreement, or other 
## applicable license agreement, including, without limitation, 
## that your use is for the sole purpose of programming logic 
## devices manufactured by Altera and sold by Altera or its 
## authorized distributors.  Please refer to the applicable 
## agreement for further details.


## VENDOR  "Altera"
## PROGRAM "Quartus II"
## VERSION "Version 14.0.1 Build 203 07/30/2014 SJ Full Version"

## DATE    "Wed Aug 13 15:13:56 2014"

##
## DEVICE  "10M50DAF484C6GES"
##


#**************************************************************
# Time Information
#**************************************************************

set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************

derive_pll_clocks

create_clock -name {altera_reserved_tck} -period 40.800 -waveform { 0.000 20.400 } [get_ports { altera_reserved_tck }]
set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tdi]
set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tms]
set_output_delay -clock altera_reserved_tck -clock_fall -max 5 [get_ports altera_reserved_tdo]
set_clock_groups -asynchronous -group [get_clocks {altera_reserved_tck}] 

create_clock -name {usb_clk} -period 20.833 -waveform { 0.000 10.416 } [get_ports {usb_clk}]
create_clock -name {clk_50_max10} -period 20.000 -waveform { 0.000 10.000 } [get_ports {clk_50_max10}]
create_clock -name {clk_10_adc} -period 100.000 -waveform { 0.000 50.000 } [get_ports {clk_10_adc}]
create_clock -name {clk_25_max10} -period 40.000 -waveform { 0.000 20.000 } [get_ports {clk_25_max10}]

create_clock -period 20.833 -name usb_clk_v_in;  # virtual clock for input constraint
create_clock -period 20.833 -name usb_clk_v_out; # virtual clock for output constraint

#**************************************************************
# Create Generated Clock
#**************************************************************

create_generated_clock -name sclk_div -source [get_ports {clk_25_max10}] -divide_by 2 [get_nets {spi_master:spi_master_dac|sclk}]
create_generated_clock -name dac_sclk -source [get_nets {spi_master:spi_master_dac|sclk}] [get_ports {dac_sclk}]

#**************************************************************
# Set Clock Latency
#**************************************************************



#**************************************************************
# Set Clock Uncertainty
#**************************************************************

derive_clock_uncertainty

#**************************************************************
# Set Input Delay
#**************************************************************

set_input_delay -clock usb_clk_v_in -max 3 [get_ports {usb_data[*] usb_addr[*] usb_oen usb_rdn usb_resetn usb_wrn usb_scl usb_sda}]
set_input_delay -clock usb_clk_v_in -min 2 [get_ports {usb_data[*] usb_addr[*] usb_oen usb_rdn usb_resetn usb_wrn usb_scl usb_sda}]

#set_input_delay -clock clk_50_max10 -max 5 [get_ports {hsmc_rx*}]
#set_input_delay -clock clk_50_max10 -min 5 [get_ports {hsmc_rx*}]

#**************************************************************
# Set Output Delay
#**************************************************************

set_output_delay -clock dac_sclk -clock_fall -max 5 [get_ports {dac_din dac_sync}]
set_output_delay -clock dac_sclk -clock_fall -min -4.5 [get_ports {dac_din dac_sync}]

set_output_delay -clock usb_clk_v_out -max 2 [get_ports {usb_addr[*] usb_data[*] usb_empty usb_full usb_scl usb_sda}]
set_output_delay -clock usb_clk_v_out -min -1 [get_ports {usb_addr[*] usb_data[*] usb_empty usb_full usb_scl usb_sda}]

#set_output_delay -clock clk_50_max10 -max 5 [get_ports {hsmc_tx*}]
#set_output_delay -clock clk_50_max10 -min -5 [get_ports {hsmc_tx*}]

set_output_delay -clock { clk_50_max10 } -rise -min 11 [get_ports {qspi_io[*]}]
set_output_delay -clock { clk_50_max10 } -rise -min 11 [get_ports {qspi_clk}]
set_output_delay -clock { clk_50_max10 } -rise -min 11 [get_ports {qspi_csn}]
set_input_delay  -clock { clk_50_max10 } -rise -min 10 [get_ports {qspi_io[*]}]

#**************************************************************
# Set Clock Groups
#**************************************************************



#**************************************************************
# Set False Path
#**************************************************************

set_false_path -from [get_registers {*altera_avalon_st_clock_crosser:*|in_data_buffer*}] -to [get_registers {*altera_avalon_st_clock_crosser:*|out_data_buffer*}]
set_false_path -to [get_keepers {*altera_std_synchronizer:*|din_s1}]
set_false_path -from [get_ports {fpga_resetn}] 
set_false_path -from [get_ports {user_dipsw[*]}] 
set_false_path -from [get_ports {user_pb[*]}] 
set_false_path -from [get_ports {adc2in[*]}] 
set_false_path -from [get_ports {pmoda_io[0]}] 
set_false_path -from [get_ports {pmoda_io[1]}] 
set_false_path -from [get_ports {pmoda_io[2]}] 
set_false_path -from [get_ports {pmoda_io[3]}] 
set_false_path -from [get_ports {pmodb_io[0]}] 
set_false_path -from [get_ports {pmodb_io[1]}] 
set_false_path -from [get_ports {pmodb_io[2]}] 
set_false_path -from [get_ports {pmodb_io[3]}] 
set_false_path -to [get_ports {adc1in[*]}]
set_false_path -to [get_ports {user_led[*]}]
set_false_path -to [get_ports {pmoda_io[4]}]
set_false_path -to [get_ports {pmoda_io[5]}]
set_false_path -to [get_ports {pmoda_io[6]}]
set_false_path -to [get_ports {pmoda_io[7]}]
set_false_path -to [get_ports {pmodb_io[4]}]
set_false_path -to [get_ports {pmodb_io[5]}]
set_false_path -to [get_ports {pmodb_io[6]}]
set_false_path -to [get_ports {pmodb_io[7]}]
set_false_path -from [get_registers {*altera_jtag_src_crosser:*|sink_data_buffer*}] -to [get_registers {*altera_jtag_src_crosser:*|src_data*}]
set_false_path -to [get_pins -nocase -compatibility_mode {*|alt_rst_sync_uq1|altera_reset_synchronizer_int_chain*|clrn}]

set_false_path -to [get_ports {dac_sclk}]
set_false_path -to [get_ports {uart_tx}]

#**************************************************************
# Set Multicycle Path
#**************************************************************



#**************************************************************
# Set Maximum Delay
#**************************************************************

set_max_delay -to [get_pins {usb_data[*]~output|i}] 3

#**************************************************************
# Set Minimum Delay
#**************************************************************



#**************************************************************
# Set Input Transition
#**************************************************************

