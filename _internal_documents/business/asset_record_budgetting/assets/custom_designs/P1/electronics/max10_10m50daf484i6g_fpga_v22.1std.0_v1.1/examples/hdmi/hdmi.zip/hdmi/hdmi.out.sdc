#**************************************************************
# HELP: http://www.altera.co.uk/literature/manual/mnl_timequest_cookbook.pdf
#**************************************************************

derive_pll_clocks

#**************************************************************
# Create Clock
#**************************************************************

create_clock -name {altera_reserved_tck} -period 40.800 -waveform { 0.000 20.400 } [get_ports { altera_reserved_tck }]
set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tdi]
set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tms]
set_output_delay -clock altera_reserved_tck -clock_fall -max 5 [get_ports altera_reserved_tdo]
set_clock_groups -asynchronous -group [get_clocks {altera_reserved_tck}] 

create_clock -name {clk_50_max10} -period 20.000 -waveform { 0.000 10.000 } [get_ports {clk_50_max10}]
create_clock -name {clk_25_max10} -period 40.000 -waveform { 0.000 20.000 } [get_ports {clk_25_max10}]
create_clock -name {clk_10_adc} -period 100.000 -waveform { 0.000 50.000 } [get_ports {clk_10_adc}]
create_clock -name {clk_ddr3_100_p} -period 10.000 -waveform { 0.000 5.000 } [get_ports {clk_ddr3_100_p}]
create_clock -name {clk_lvds_125_p} -period 8.000 -waveform { 0.000 4.000 } [get_ports {clk_lvds_125_p}]


#**************************************************************
# Create Generated Clock
#**************************************************************

create_generated_clock -name {u_hdmi_qsys|altpll_0|sd1|pll7|clk[0]} -source [get_pins {u_hdmi_qsys|altpll_0|sd1|pll7|inclk[0]}] -multiply_by 3 -duty_cycle 50.000 [get_pins {u_hdmi_qsys|altpll_0|sd1|pll7|clk[0]}]

create_generated_clock -name {hdmi_tx_clk} -source [get_pins {u_hdmi_qsys|altpll_0|sd1|pll7|clk[0]}] [get_ports {hdmi_tx_clk}]

#**************************************************************
# Set Clock Latency
#**************************************************************

#**************************************************************
# Set Clock Uncertainty
#**************************************************************

derive_clock_uncertainty

#**************************************************************
# Set Input Delay
#**************************************************************

set_input_delay -clock clk_50_max10 -max 3 [get_ports {hdmi_sda}]
set_input_delay -clock clk_50_max10 -min 2 [get_ports {hdmi_sda}]

#**************************************************************
# Set Output Delay
#**************************************************************

set_output_delay -clock hdmi_tx_clk -max 3 [get_ports {hdmi_tx_d[*]}]
set_output_delay -clock hdmi_tx_clk -min 2 [get_ports {hdmi_tx_d[*]}]
set_output_delay -clock hdmi_tx_clk -max 3 [get_ports {hdmi_tx_hs}]
set_output_delay -clock hdmi_tx_clk -min 2 [get_ports {hdmi_tx_hs}]
set_output_delay -clock hdmi_tx_clk -max 3 [get_ports {hdmi_tx_vs}]
set_output_delay -clock hdmi_tx_clk -min 2 [get_ports {hdmi_tx_vs}]
set_output_delay -clock hdmi_tx_clk -max 3 [get_ports {hdmi_tx_de}]
set_output_delay -clock hdmi_tx_clk -min 2 [get_ports {hdmi_tx_de}]

set_output_delay -clock clk_50_max10 -max 3 [get_ports {hdmi_sda}]
set_output_delay -clock clk_50_max10 -min 2 [get_ports {hdmi_sda}]
set_output_delay -clock clk_50_max10 -max 3 [get_ports {hdmi_scl}]
set_output_delay -clock clk_50_max10 -min 2 [get_ports {hdmi_scl}]

#**************************************************************
# Set Clock Groups
#**************************************************************

#**************************************************************
# Set False Path
#**************************************************************

set_false_path -from [get_ports {fpga_resetn}]
set_false_path -from [get_ports {user_dipsw[*]}]
set_false_path -from [get_ports {user_pb[*]}]
set_false_path -to [get_ports {user_led[*]}]

set_false_path -from [get_ports {hdmi_tx_int}]
set_false_path -to [get_ports {hdmi_tx_clk}]

#**************************************************************
# Set Multicycle Path
#**************************************************************

#**************************************************************
# Set Maximum Delay
#**************************************************************

#**************************************************************
# Set Minimum Delay
#**************************************************************

#**************************************************************
# Set Input Transition
#**************************************************************

#**************************************************************
# Set Load
#**************************************************************



