
module mSGDMA (
	cal_fail_mon_export,
	cal_success_mon_export,
	clk_clk,
	clk_0_clk,
	dispatcher_read_csr_irq_irq,
	dispatcher_write_csr_irq_irq,
	dma_read_master_address,
	dma_read_master_read,
	dma_read_master_byteenable,
	dma_read_master_readdata,
	dma_read_master_waitrequest,
	dma_read_master_readdatavalid,
	dma_read_master_burstcount,
	dma_write_master_address,
	dma_write_master_write,
	dma_write_master_byteenable,
	dma_write_master_writedata,
	dma_write_master_waitrequest,
	dma_write_master_burstcount,
	eset_source_reset_n,
	mm_bridge_slv_waitrequest,
	mm_bridge_slv_readdata,
	mm_bridge_slv_readdatavalid,
	mm_bridge_slv_burstcount,
	mm_bridge_slv_writedata,
	mm_bridge_slv_address,
	mm_bridge_slv_write,
	mm_bridge_slv_read,
	mm_bridge_slv_byteenable,
	mm_bridge_slv_debugaccess,
	reset_reset_n,
	reset_0_reset_n,
	status_mon_0_init_done_mon_export,
	status_mon_in_local_init_done,
	status_mon_in_local_cal_success,
	status_mon_in_local_cal_fail);	

	output		cal_fail_mon_export;
	output		cal_success_mon_export;
	input		clk_clk;
	input		clk_0_clk;
	output		dispatcher_read_csr_irq_irq;
	output		dispatcher_write_csr_irq_irq;
	output	[31:0]	dma_read_master_address;
	output		dma_read_master_read;
	output	[15:0]	dma_read_master_byteenable;
	input	[127:0]	dma_read_master_readdata;
	input		dma_read_master_waitrequest;
	input		dma_read_master_readdatavalid;
	output	[5:0]	dma_read_master_burstcount;
	output	[31:0]	dma_write_master_address;
	output		dma_write_master_write;
	output	[15:0]	dma_write_master_byteenable;
	output	[127:0]	dma_write_master_writedata;
	input		dma_write_master_waitrequest;
	output	[5:0]	dma_write_master_burstcount;
	output		eset_source_reset_n;
	output		mm_bridge_slv_waitrequest;
	output	[31:0]	mm_bridge_slv_readdata;
	output		mm_bridge_slv_readdatavalid;
	input	[6:0]	mm_bridge_slv_burstcount;
	input	[31:0]	mm_bridge_slv_writedata;
	input	[19:0]	mm_bridge_slv_address;
	input		mm_bridge_slv_write;
	input		mm_bridge_slv_read;
	input	[3:0]	mm_bridge_slv_byteenable;
	input		mm_bridge_slv_debugaccess;
	input		reset_reset_n;
	input		reset_0_reset_n;
	output		status_mon_0_init_done_mon_export;
	input		status_mon_in_local_init_done;
	input		status_mon_in_local_cal_success;
	input		status_mon_in_local_cal_fail;
endmodule
