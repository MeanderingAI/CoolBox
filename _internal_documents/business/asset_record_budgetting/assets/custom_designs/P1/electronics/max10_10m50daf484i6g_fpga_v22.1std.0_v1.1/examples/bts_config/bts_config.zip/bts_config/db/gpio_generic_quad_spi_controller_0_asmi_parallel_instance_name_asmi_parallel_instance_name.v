//altasmi_parallel CBX_AUTO_BLACKBOX="ALL" CBX_SINGLE_OUTPUT_FILE="ON" DATA_WIDTH="QUAD" DEVICE_FAMILY="MAX 10" ENABLE_SIM="TRUE" EPCS_TYPE="EPCQL512" FLASH_RSTPIN="TRUE" PAGE_SIZE=256 PORT_BULK_ERASE="PORT_UNUSED" PORT_DIE_ERASE="PORT_UNUSED" PORT_EN4B_ADDR="PORT_USED" PORT_EX4B_ADDR="PORT_UNUSED" PORT_FAST_READ="PORT_USED" PORT_ILLEGAL_ERASE="PORT_USED" PORT_ILLEGAL_WRITE="PORT_USED" PORT_RDID_OUT="PORT_USED" PORT_READ_ADDRESS="PORT_UNUSED" PORT_READ_DUMMYCLK="PORT_USED" PORT_READ_RDID="PORT_USED" PORT_READ_SID="PORT_UNUSED" PORT_READ_STATUS="PORT_USED" PORT_SECTOR_ERASE="PORT_USED" PORT_SECTOR_PROTECT="PORT_USED" PORT_SHIFT_BYTES="PORT_USED" PORT_WREN="PORT_USED" PORT_WRITE="PORT_USED" USE_ASMIBLOCK="OFF" USE_EAB="ON" WRITE_DUMMY_CLK=0 addr asmi_dataoe asmi_dataout asmi_dclk asmi_scein asmi_sdoin busy clkin data_valid datain dataout en4b_addr fast_read illegal_erase illegal_write rden rdid_out read_dummyclk read_rdid read_status reset sector_erase sector_protect shift_bytes status_out wren write CYCLONEII_M4K_COMPATIBILITY="ON" INTENDED_DEVICE_FAMILY="MAX 10" LOW_POWER_MODE="AUTO" ALTERA_INTERNAL_OPTIONS=SUPPRESS_DA_RULE_INTERNAL=C106
//VERSION_BEGIN 22.1 cbx_a_gray2bin 2022:10:25:15:32:10:SC cbx_a_graycounter 2022:10:25:15:32:10:SC cbx_altasmi_parallel 2022:10:25:15:32:10:SC cbx_altdpram 2022:10:25:15:32:10:SC cbx_altera_counter 2022:10:25:15:32:10:SC cbx_altera_syncram 2022:10:25:15:32:10:SC cbx_altera_syncram_nd_impl 2022:10:25:15:32:10:SC cbx_altsyncram 2022:10:25:15:32:10:SC cbx_arriav 2022:10:25:15:32:09:SC cbx_cyclone 2022:10:25:15:32:10:SC cbx_cycloneii 2022:10:25:15:32:10:SC cbx_fifo_common 2022:10:25:15:32:10:SC cbx_lpm_add_sub 2022:10:25:15:32:10:SC cbx_lpm_compare 2022:10:25:15:32:10:SC cbx_lpm_counter 2022:10:25:15:32:10:SC cbx_lpm_decode 2022:10:25:15:32:10:SC cbx_lpm_mux 2022:10:25:15:32:10:SC cbx_mgl 2022:10:25:15:42:35:SC cbx_nadder 2022:10:25:15:32:10:SC cbx_nightfury 2022:10:25:15:32:10:SC cbx_scfifo 2022:10:25:15:32:10:SC cbx_stratix 2022:10:25:15:32:10:SC cbx_stratixii 2022:10:25:15:32:10:SC cbx_stratixiii 2022:10:25:15:32:10:SC cbx_stratixv 2022:10:25:15:32:10:SC cbx_util_mgl 2022:10:25:15:32:10:SC cbx_zippleback 2022:10:25:15:32:10:SC  VERSION_END
// synthesis VERILOG_INPUT_VERSION VERILOG_2001
// altera message_off 10463



// Copyright (C) 2022  Intel Corporation. All rights reserved.
//  Your use of Intel Corporation's design tools, logic functions 
//  and other software and tools, and any partner logic 
//  functions, and any output files from any of the foregoing 
//  (including device programming or simulation files), and any 
//  associated documentation or information are expressly subject 
//  to the terms and conditions of the Intel Program License 
//  Subscription Agreement, the Intel Quartus Prime License Agreement,
//  the Intel FPGA IP License Agreement, or other applicable license
//  agreement, including, without limitation, that your use is for
//  the sole purpose of programming logic devices manufactured by
//  Intel and sold by Intel or its authorized distributors.  Please
//  refer to the applicable agreement for further details, at
//  https://fpgasoftware.intel.com/eula.



//synthesis_resources = lut 70 
//synopsys translate_off
`timescale 1 ps / 1 ps
//synopsys translate_on
(* ALTERA_ATTRIBUTE = {"SUPPRESS_DA_RULE_INTERNAL=C106"} *)
module  gpio_generic_quad_spi_controller_0_asmi_parallel_instance_name_asmi_parallel_instance_name
	( 
	addr,
	asmi_dataoe,
	asmi_dataout,
	asmi_dclk,
	asmi_scein,
	asmi_sdoin,
	busy,
	clkin,
	data_valid,
	datain,
	dataout,
	en4b_addr,
	fast_read,
	illegal_erase,
	illegal_write,
	rden,
	rdid_out,
	read_dummyclk,
	read_rdid,
	read_status,
	reset,
	sector_erase,
	sector_protect,
	shift_bytes,
	status_out,
	wren,
	write) /* synthesis synthesis_clearbox=1 */;
	input   [31:0]  addr;
	output   [3:0]  asmi_dataoe;
	input   [3:0]  asmi_dataout;
	output   asmi_dclk;
	output   asmi_scein;
	output   [3:0]  asmi_sdoin;
	output   busy;
	input   clkin;
	output   data_valid;
	input   [7:0]  datain;
	output   [7:0]  dataout;
	input   en4b_addr;
	input   fast_read;
	output   illegal_erase;
	output   illegal_write;
	input   rden;
	output   [7:0]  rdid_out;
	input   read_dummyclk;
	input   read_rdid;
	input   read_status;
	input   reset;
	input   sector_erase;
	input   sector_protect;
	input   shift_bytes;
	output   [7:0]  status_out;
	input   wren;
	input   write;
`ifndef ALTERA_RESERVED_QIS
// synopsys translate_off
`endif
	tri0   [3:0]  asmi_dataout;
	tri0   [7:0]  datain;
	tri0   en4b_addr;
	tri0   fast_read;
	tri0   read_dummyclk;
	tri0   read_rdid;
	tri0   read_status;
	tri0   reset;
	tri0   sector_erase;
	tri0   sector_protect;
	tri0   shift_bytes;
	tri1   wren;
	tri0   write;
`ifndef ALTERA_RESERVED_QIS
// synopsys translate_on
`endif


	initial/*synthesis enable_verilog_initial_construct*/
 	begin
		$display("Error: Selected device family, (MAX 10), does not support dual or quad data transfer");
	end
endmodule //gpio_generic_quad_spi_controller_0_asmi_parallel_instance_name_asmi_parallel_instance_name
//ERROR FILE
