/*******************************************************************************
*
* Copyright (C) 2018-2024 Intel Corporation
* 
* This code and the related documents are Intel copyrighted materials, and 
* your use of them is governed by the express license under which they were 
* provided to you ("License"). Unless the License provides otherwise, you may 
* not use, modify, copy, publish, distribute, disclose or transmit this 
* code or the related documents without Intel's prior written permission.
*
* This code and the related documents are provided as is, with no express 
* or implied warranties, other than those that are expressly stated in the 
* License.
*
*******************************************************************************/

`timescale 1 ps / 1 ps
module  bts_config (
        //Reset and Clocks
        input           clk_ddr3_100_p,
        input           clk_50_max10,
        input           clk_25_max10,
        input           clk_lvds_125_p,
        input           clk_10_adc,
        input           fpga_resetn,
        
        //LED PB DIPSW
        output [4:0]    user_led,
        input  [3:0]    user_pb,
        input  [4:0]    user_dipsw,
        
        //USB 
        input           usb_resetn,
        input           usb_wrn,
        input           usb_rdn,
        input           usb_oen,
        inout  [1:0]    usb_addr,
        inout  [7:0]    usb_data,
        output          usb_full,
        output          usb_empty,
        inout           usb_scl,
        inout           usb_sda,
        input           usb_clk,
        
        //HSMC
        //input  [2:1]  hsmc_clk_in_p,
        //input         hsmc_clk_in0,
        //output [2:1]  hsmc_clk_out_p,
        //input  [16:0] hsmc_rx_d_p,
        //output [16:0] hsmc_tx_d_p,
        
        //PMOD
        inout  [7:0]    pmoda_io,
        inout  [7:0]    pmodb_io,
        
        //QSPI
        output          qspi_clk,
        inout  [3:0]    qspi_io,
        output          qspi_csn,
        
        //DAC
        output          dac_sync,
        output          dac_sclk,
        output          dac_din,
        
        //GPIO
        output [8:1]    adc1in,
        input  [8:1]    adc2in,

        input           uart_rx,
        output          uart_tx,
        
        //JTAG
        output          ip_sequrity,
        output          jtag_safe
        );

parameter      SLAVES        = 1;  // Slave target number
parameter      DATA_WIDTH    = 24; // Data width
parameter      CLK_DIV       = 0;  // system clock cycles per 1/2 period of sclk, CLK_DIV ==0 -> no division
parameter      ADDR          = 0;  // address of slave

wire   [7:0]   adc1in_int;
wire   [7:0]   adc2in_int;

wire           cpol/* synthesis keep */;     // SPI clock polarity setting
wire           cpha/* synthesis keep */;     // SPI clock phase setting
wire           enable/* synthesis keep */;   // H: latches in settings, address, and data to initiate a transaction, L: no transaction is initiated.
wire           cont/* synthesis keep */;     // Continuous mode flag
wire   [17:0]  dac_ctrl/* synthesis keep */; // DAC control and data
wire   [23:0]  tx_data;                      // SPI Tx data

wire   [7:0]   pmod_in/* synthesis keep */;
wire   [7:0]   pmod_out/* synthesis keep */;

assign         cpol          = 1'b1;
assign         cpha          = 1'b0;
assign         enable        = dac_ctrl[17];
assign         cont          = dac_ctrl[16];
assign         tx_data       = {6'b000000, 2'b00, dac_ctrl[15:0]}; // reserve bits, operation mode setting (default: normal mode) and DAC data

//Loopback mapping:
//0 <-> 4
//1 <-> 5
//2 <-> 6
//3 <-> 7
assign         pmod_in       = {pmoda_io[3:0], pmodb_io[3:0]};
assign         pmoda_io[3:0] = 4'hz;
assign         pmodb_io[3:0] = 4'hz;
assign         pmoda_io[7:4] = pmod_out[7:4];
assign         pmodb_io[7:4] = pmod_out[3:0];

//Loopback mapping:
//0 <-> 1
//2 <-> 3
//4 <-> 5
//6 <-> 7
/*
assign         pmod_in       = {pmoda_io[6], pmoda_io[4], pmoda_io[2], pmoda_io[0], pmodb_io[6], pmodb_io[4], pmodb_io[2], pmodb_io[0]};

assign        pmoda_io[7]    = pmod_out[7];
assign        pmoda_io[5]    = pmod_out[6];
assign        pmoda_io[3]    = pmod_out[5];
assign        pmoda_io[1]    = pmod_out[4];
assign        pmodb_io[7]    = pmod_out[3];
assign        pmodb_io[5]    = pmod_out[2];
assign        pmodb_io[3]    = pmod_out[1];
assign        pmodb_io[1]    = pmod_out[0];

assign        pmoda_io[0]    = 1'bz;
assign        pmoda_io[2]    = 1'bz;
assign        pmoda_io[4]    = 1'bz;
assign        pmoda_io[6]    = 1'bz;
assign        pmodb_io[0]    = 1'bz;
assign        pmodb_io[2]    = 1'bz;
assign        pmodb_io[4]    = 1'bz;
assign        pmodb_io[6]    = 1'bz;
*/

gpio            gpio_u0 (
                        .clk_50m_clk                                                   (clk_50_max10    ), //                                      clk_50m.clk
                        .reset_50m_reset_n                                             (fpga_resetn     ), //                                    reset_50m.reset_n
                        .usb_debug_master_0_usb_if_clk                                 (usb_clk         ), //                    usb_debug_master_0_usb_if.clk
                        .usb_debug_master_0_usb_if_reset_n                             (usb_resetn      ), //                                             .reset_n
                        .usb_debug_master_0_usb_if_full                                (usb_full        ), //                                             .full
                        .usb_debug_master_0_usb_if_empty                               (usb_empty       ), //                                             .empty
                        .usb_debug_master_0_usb_if_wr_n                                (usb_wrn         ), //                                             .wr_n
                        .usb_debug_master_0_usb_if_rd_n                                (usb_rdn         ), //                                             .rd_n
                        .usb_debug_master_0_usb_if_oe_n                                (usb_oen         ), //                                             .oe_n
                        .usb_debug_master_0_usb_if_data                                (usb_data        ), //                                             .data
                        .usb_debug_master_0_usb_if_addr                                (usb_addr        ), //                                             .addr
                        .usb_debug_master_0_usb_if_scl                                 (usb_scl         ), //                                             .scl
                        .usb_debug_master_0_usb_if_sda                                 (usb_sda         ), //                                             .sda
                        .user_led_external_connection_export                           (user_led        ), //                 user_led_external_connection.export
                        .user_pb_external_connection_export                            (user_pb         ), //                  user_pb_external_connection.export
                        .user_dipsw_external_connection_export                         (user_dipsw      ), //               user_dipsw_external_connection.export
                        .adc1_out_external_connection_in_port                          (adc1in_int      ), //                 adc1_out_external_connection.in_port
                        .adc1_out_external_connection_out_port                         (adc1in_int      ), //                                             .out_port
                        .adc2_in_external_connection_export                            (adc2in_int      ), //                  adc2_in_external_connection.export
                        .pmod_output_external_connection_in_port                       (pmod_out        ), //              pmod_output_external_connection.in_port
                        .pmod_output_external_connection_out_port                      (pmod_out        ), //                                             .out_port
                        .pmod_input_external_connection_export                         (pmod_in         ), //               pmod_input_external_connection.export
                        .generic_quad_spi_controller_0_flash_dataout_conduit_dataout   (qspi_io         ), //  generic_quad_spi_controller_0_flash_dataout.conduit_dataout
                        .generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out (qspi_clk        ), // generic_quad_spi_controller_0_flash_dclk_out.conduit_dclk_out
                        .generic_quad_spi_controller_0_flash_ncs_conduit_ncs           (qspi_csn        ), //      generic_quad_spi_controller_0_flash_ncs.conduit_ncs
                        .uart_0_external_connection_rxd                                (uart_rx         ), //                   uart_0_external_connection.rxd
                        .uart_0_external_connection_txd                                (uart_tx         ), //                                             .txd
                        .dac_ctrl_external_connection_export                           (dac_ctrl        )  //                 dac_ctrl_external_connection.export
                        );

spi_master              #(
                        .slaves                                 (SLAVES        ), // 
                        .d_width                                (DATA_WIDTH    )  // 
                        )
                        spi_master_dac
                        (
                        .clock                                  (clk_25_max10  ), // system clock
                        .reset_n                                (fpga_resetn   ), // asynchronous reset
                        .enable                                 (enable        ), // initiate transaction
                        .cpol                                   (cpol          ), // spi clock polarity
                        .cpha                                   (cpha          ), // spi clock phase
                        .cont                                   (cont          ), // continuous mode command
                        .clk_div                                (CLK_DIV       ), // system clock cycles per 1/2 period of sclk
                        .addr                                   (ADDR          ), // address of slave
                        .tx_data                                (tx_data       ), // data to transmit
                        //.miso                                 (              ), // master in, slave out
                        .sclk                                   (dac_sclk      ), // spi clock
                        .ss_n                                   (dac_sync      ), // slave select
                        .mosi                                   (dac_din       )  // master out, slave in
                        //.busy                                 (              ), // busy / data ready signal
                        //.rx_data                              (              )  // data received
                        );

assign ip_sequrity = 1'b0;
assign jtag_safe   = 1'b0;

assign adc1in      = adc1in_int;
assign adc2in_int  = adc2in;

endmodule
