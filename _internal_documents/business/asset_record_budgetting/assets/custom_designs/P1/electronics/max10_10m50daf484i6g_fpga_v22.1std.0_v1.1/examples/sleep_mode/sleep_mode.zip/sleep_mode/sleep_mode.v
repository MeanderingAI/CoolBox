/*******************************************************************************
*
* Copyright (C) 2018-2024 Intel Corporation
* 
* This code and the related documents are Intel copyrighted materials, and 
* your use of them is governed by the express license under which they were 
* provided to you ("License"). Unless the License provides otherwise, you may 
* not use, modify, copy, publish, distribute, disclose or transmit this 
* code or the related documents without Intel's prior written permission.
*
* This code and the related documents are provided as is, with no express 
* or implied warranties, other than those that are expressly stated in the 
* License.
*
*******************************************************************************/

`timescale 1 ps / 1 ps
module sleep_mode (
		//Reset and Clocks
		input           clk_ddr3_100_p,
		input           clk_50_max10,
		input           clk_25_max10,
		input           clk_10_adc,
		input           fpga_resetn,
		input           clk_lvds_125_p,
		
		//LED PB DIPSW
		output [4:0]    user_led,
		input  [3:0]    user_pb,
		input  [4:0]    user_dipsw,
		
		//PMOD
		//inout  [7:0]  pmoda_io,
		output   [7:0]  pmodb_io
	);

parameter               CNT_WIDTH    = 8;
parameter               CNT_NUMBER   = 3840; // To be N X 64
parameter               DIV_FACTOR_1 = 8;    // 
parameter               DIV_FACTOR_2 = 64;   // 
parameter               FILTER_WIDTH = 10;   // even number: 2, 4, 6, 8 ...
parameter               INIT_BIT     = 0 ;   // 0: 1'b0; 1: 1'b1;

wire                    clk_100m;
wire                    clk_1m;
wire                    pll_locked;
reg                     clk_enable/* synthesis keep */;
wire                    clk_ctrl_output;

wire                    user_pb_filtered;
reg                     user_pb_filtered_reg1;
reg                     user_pb_filtered_reg2;
wire                    user_pb_filtered_pos;

wire                    clk_ctrl_gui;
reg                     clk_ctrl_gui_reg1;
reg                     clk_ctrl_gui_reg2;
wire                    clk_ctrl_gui_pos;
wire                    clk_ctrl_gui_neg;
wire                    clk_ctrl_gui_edge;

wire                    clk_ctrl_pulse;

reg    [26:0]           heart_beat_cnt;

reg    [CNT_WIDTH-1:0]  led_flash_cnt [0:CNT_NUMBER-1];
reg    [CNT_NUMBER-1:0] led_flash_cnt_ands;
reg    [CNT_NUMBER/DIV_FACTOR_1-1:0] led_flash_cnt_ands_1;
reg    [CNT_NUMBER/DIV_FACTOR_2-1:0] led_flash_cnt_ands_2;

////////////////////////////////////////////////////////////////////////////////////////////////////////
//Clock BUFFER
////////////////////////////////////////////////////////////////////////////////////////////////////////
adc_pll     	adc_pll_100m	(
								.areset		(!fpga_resetn		),
								.inclk0		(clk_50_max10		),
								.c0			(clk_100m			),
								.c1			(clk_1m				),
								.locked		(pll_locked			)
								);

clk_ctrl		clk_ctrl_50m	(
								.inclk		(clk_100m			), // clk_25_max10		), //  altclkctrl_input.inclk
								.ena		(clk_enable			), //                  .ena
								.outclk		(clk_ctrl_output	)  // altclkctrl_output.outclk
								);

////////////////////////////////////////////////////////////////////////////////////////////////////////
//Sleep Mode Control
////////////////////////////////////////////////////////////////////////////////////////////////////////
filter_circuit      #(
                    .FILTER_WIDTH			(FILTER_WIDTH		), // even number excepts 0, such as 2, 4, 6, 8 ...
                    .INIT_BIT				(INIT_BIT			)  // initialization bit, 0 or 1
                    )
                    filter_circuit_inst
                    (
                    .i_clk_rst				(!fpga_resetn		), // reset
                    .i_clk					(clk_1m				), // clock
                    .i_framein				(user_pb[0]			), // input
                    .o_frameout				(user_pb_filtered	)  // output
                    );

always @(posedge clk_50_max10 or negedge fpga_resetn)
  if (!fpga_resetn)
      begin
      user_pb_filtered_reg1 <= 1'b0;
      user_pb_filtered_reg2 <= 1'b0;
      end
  else
      begin
      user_pb_filtered_reg1 <= user_pb_filtered;
      user_pb_filtered_reg2 <= user_pb_filtered_reg1;
      end

assign user_pb_filtered_pos = user_pb_filtered_reg1 & (!user_pb_filtered_reg2); // Posedge of user_pb[0]

//-----------------------------------------------------------------------------

always @(posedge clk_50_max10 or negedge fpga_resetn)
  if (!fpga_resetn)
      begin
      clk_ctrl_gui_reg1 <= 1'b0;
      clk_ctrl_gui_reg2 <= 1'b0;
      end
  else
      begin
      clk_ctrl_gui_reg1 <= clk_ctrl_gui;
      clk_ctrl_gui_reg2 <= clk_ctrl_gui_reg1;
      end

assign clk_ctrl_gui_pos  = clk_ctrl_gui_reg1 & (!clk_ctrl_gui_reg2); // Posedge of clk_ctrl_gui
assign clk_ctrl_gui_neg  = clk_ctrl_gui_reg2 & (!clk_ctrl_gui_reg1); // Negedge of clk_ctrl_gui
assign clk_ctrl_gui_edge = clk_ctrl_gui_pos | clk_ctrl_gui_neg;      // Edeg of clk_ctrl_gui

assign clk_ctrl_pulse = user_pb_filtered_pos | clk_ctrl_gui_edge;

//-----------------------------------------------------------------------------
always @(posedge clk_50_max10 or negedge fpga_resetn)
  if (!fpga_resetn)
      clk_enable <= 1'b0;
  else if(clk_ctrl_pulse)
      clk_enable <= !clk_enable;

////////////////////////////////////////////////////////////////////////////////////////////////////////
//Heart beat by 50MHz clock
always @(posedge clk_50_max10 or negedge fpga_resetn)
  if (!fpga_resetn)
      heart_beat_cnt <= 27'h0; //0x7FFFFFF
  else
      heart_beat_cnt <= heart_beat_cnt + 1'b1;

////////////////////////////////////////////////////////////////////////////////////////////////////////
//For Clock Sleep Mode Demo
////////////////////////////////////////////////////////////////////////////////////////////////////////
//LED_FLASH_CNT[N]
genvar i;
generate
for(i=0; i<CNT_NUMBER; i=i+1)
begin: Counters
  always @(posedge clk_ctrl_output or negedge fpga_resetn)
    if (!fpga_resetn)
        led_flash_cnt[i] <= 8'h0;
    else
        led_flash_cnt[i] <= led_flash_cnt[i] + 1'b1;
end
endgenerate

genvar j;
generate
for(j=0; j<CNT_NUMBER; j=j+1)
begin: Bit_And_0
  always @(posedge clk_ctrl_output or negedge fpga_resetn)
    if (!fpga_resetn)
        led_flash_cnt_ands[j] <= 1'b0;
    else
        led_flash_cnt_ands[j] <= &led_flash_cnt[j];
end
endgenerate

genvar k;
generate
for(k=0; k<CNT_NUMBER/DIV_FACTOR_1; k=k+1)
begin: Bit_And_1
  always @(posedge clk_ctrl_output or negedge fpga_resetn)
    if (!fpga_resetn)
        led_flash_cnt_ands_1[k] <= 1'b0;
    else
        led_flash_cnt_ands_1[k] <= &led_flash_cnt_ands[k*DIV_FACTOR_1+DIV_FACTOR_1-1:k*DIV_FACTOR_1];
end
endgenerate

genvar l;
generate
for(l=0; l<CNT_NUMBER/DIV_FACTOR_2; l=l+1)
begin: Bit_And_2
  always @(posedge clk_ctrl_output or negedge fpga_resetn)
    if (!fpga_resetn)
        led_flash_cnt_ands_2[l] <= 1'b0;
    else
        led_flash_cnt_ands_2[l] <= &led_flash_cnt_ands_1[l*DIV_FACTOR_1+DIV_FACTOR_1-1:l*DIV_FACTOR_1];
end
endgenerate

////////////////////////////////////////////////////////////////////////////////////////////////////////
sleep_mode_qsys         sleep_mode_qsys_u0 (
                        .clk_clk                          (clk_50_max10    ), //                       clk.clk
                        .reset_reset_n                    (fpga_resetn     ), //                     reset.reset_n
                        .pio_0_external_connection_export (clk_ctrl_gui    ), // pio_0_external_connection.export
                        .pio_1_external_connection_export (clk_enable      )  // pio_1_external_connection.export
                        );
////////////////////////////////////////////////////////////////////////////////////////////////////////
assign user_led[0] = !clk_enable | heart_beat_cnt[24];
assign user_led[1] = !clk_enable | heart_beat_cnt[24];
assign user_led[2] = heart_beat_cnt[26];
assign user_led[3] = heart_beat_cnt[26];
assign user_led[4] = heart_beat_cnt[26];

assign pmodb_io[0]   = &led_flash_cnt_ands_2; // Only for test
assign pmodb_io[7:1] = 7'h0;                  // Only for test

endmodule
