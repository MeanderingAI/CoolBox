	hsmc_qsys u0 (
		.clk_clk                                      (<connected-to-clk_clk>),                                      //                                      clk.clk
		.data_pattern_checker_0_pattern_in_valid      (<connected-to-data_pattern_checker_0_pattern_in_valid>),      //        data_pattern_checker_0_pattern_in.valid
		.data_pattern_checker_0_pattern_in_ready      (<connected-to-data_pattern_checker_0_pattern_in_ready>),      //                                         .ready
		.data_pattern_checker_0_pattern_in_data       (<connected-to-data_pattern_checker_0_pattern_in_data>),       //                                         .data
		.data_pattern_checker_0_pattern_in_clk_clk    (<connected-to-data_pattern_checker_0_pattern_in_clk_clk>),    //    data_pattern_checker_0_pattern_in_clk.clk
		.data_pattern_generator_0_pattern_out_valid   (<connected-to-data_pattern_generator_0_pattern_out_valid>),   //     data_pattern_generator_0_pattern_out.valid
		.data_pattern_generator_0_pattern_out_ready   (<connected-to-data_pattern_generator_0_pattern_out_ready>),   //                                         .ready
		.data_pattern_generator_0_pattern_out_data    (<connected-to-data_pattern_generator_0_pattern_out_data>),    //                                         .data
		.data_pattern_generator_0_pattern_out_clk_clk (<connected-to-data_pattern_generator_0_pattern_out_clk_clk>), // data_pattern_generator_0_pattern_out_clk.clk
		.reset_reset_n                                (<connected-to-reset_reset_n>),                                //                                    reset.reset_n
		.user_dipsw_external_connection_export        (<connected-to-user_dipsw_external_connection_export>),        //           user_dipsw_external_connection.export
		.user_led_external_connection_export          (<connected-to-user_led_external_connection_export>),          //             user_led_external_connection.export
		.user_pb_external_connection_export           (<connected-to-user_pb_external_connection_export>)            //              user_pb_external_connection.export
	);

