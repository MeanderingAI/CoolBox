
module q_sys (
	master_driver_msgdma_0_conduit_end_error_mon,
	master_driver_msgdma_0_conduit_end_status_mon,
	memory_mem_a,
	memory_mem_ba,
	memory_mem_ck,
	memory_mem_ck_n,
	memory_mem_cke,
	memory_mem_cs_n,
	memory_mem_dm,
	memory_mem_ras_n,
	memory_mem_cas_n,
	memory_mem_we_n,
	memory_mem_reset_n,
	memory_mem_dq,
	memory_mem_dqs,
	memory_mem_dqs_n,
	memory_mem_odt,
	msgdma_0_cal_fail_mon_export,
	msgdma_0_cal_success_mon_export,
	msgdma_0_status_mon_0_init_done_mon_export,
	refclk_clock_bridge_in_clk_clk,
	reset_reset_n,
	sys_clk_clk);	

	output		master_driver_msgdma_0_conduit_end_error_mon;
	output		master_driver_msgdma_0_conduit_end_status_mon;
	output	[12:0]	memory_mem_a;
	output	[2:0]	memory_mem_ba;
	inout	[0:0]	memory_mem_ck;
	inout	[0:0]	memory_mem_ck_n;
	output	[0:0]	memory_mem_cke;
	output	[0:0]	memory_mem_cs_n;
	output	[2:0]	memory_mem_dm;
	output	[0:0]	memory_mem_ras_n;
	output	[0:0]	memory_mem_cas_n;
	output	[0:0]	memory_mem_we_n;
	output		memory_mem_reset_n;
	inout	[23:0]	memory_mem_dq;
	inout	[2:0]	memory_mem_dqs;
	inout	[2:0]	memory_mem_dqs_n;
	output	[0:0]	memory_mem_odt;
	output		msgdma_0_cal_fail_mon_export;
	output		msgdma_0_cal_success_mon_export;
	output		msgdma_0_status_mon_0_init_done_mon_export;
	input		refclk_clock_bridge_in_clk_clk;
	input		reset_reset_n;
	input		sys_clk_clk;
endmodule
