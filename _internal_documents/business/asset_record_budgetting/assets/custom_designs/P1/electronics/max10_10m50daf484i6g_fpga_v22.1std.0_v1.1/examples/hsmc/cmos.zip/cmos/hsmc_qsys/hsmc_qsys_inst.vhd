	component hsmc_qsys is
		port (
			clk_clk                                      : in  std_logic                     := 'X';             -- clk
			data_pattern_checker_0_pattern_in_valid      : in  std_logic                     := 'X';             -- valid
			data_pattern_checker_0_pattern_in_ready      : out std_logic;                                        -- ready
			data_pattern_checker_0_pattern_in_data       : in  std_logic_vector(31 downto 0) := (others => 'X'); -- data
			data_pattern_checker_0_pattern_in_clk_clk    : in  std_logic                     := 'X';             -- clk
			data_pattern_generator_0_pattern_out_valid   : out std_logic;                                        -- valid
			data_pattern_generator_0_pattern_out_ready   : in  std_logic                     := 'X';             -- ready
			data_pattern_generator_0_pattern_out_data    : out std_logic_vector(31 downto 0);                    -- data
			data_pattern_generator_0_pattern_out_clk_clk : in  std_logic                     := 'X';             -- clk
			reset_reset_n                                : in  std_logic                     := 'X';             -- reset_n
			user_dipsw_external_connection_export        : in  std_logic_vector(4 downto 0)  := (others => 'X'); -- export
			user_led_external_connection_export          : out std_logic_vector(4 downto 0);                     -- export
			user_pb_external_connection_export           : in  std_logic_vector(3 downto 0)  := (others => 'X')  -- export
		);
	end component hsmc_qsys;

	u0 : component hsmc_qsys
		port map (
			clk_clk                                      => CONNECTED_TO_clk_clk,                                      --                                      clk.clk
			data_pattern_checker_0_pattern_in_valid      => CONNECTED_TO_data_pattern_checker_0_pattern_in_valid,      --        data_pattern_checker_0_pattern_in.valid
			data_pattern_checker_0_pattern_in_ready      => CONNECTED_TO_data_pattern_checker_0_pattern_in_ready,      --                                         .ready
			data_pattern_checker_0_pattern_in_data       => CONNECTED_TO_data_pattern_checker_0_pattern_in_data,       --                                         .data
			data_pattern_checker_0_pattern_in_clk_clk    => CONNECTED_TO_data_pattern_checker_0_pattern_in_clk_clk,    --    data_pattern_checker_0_pattern_in_clk.clk
			data_pattern_generator_0_pattern_out_valid   => CONNECTED_TO_data_pattern_generator_0_pattern_out_valid,   --     data_pattern_generator_0_pattern_out.valid
			data_pattern_generator_0_pattern_out_ready   => CONNECTED_TO_data_pattern_generator_0_pattern_out_ready,   --                                         .ready
			data_pattern_generator_0_pattern_out_data    => CONNECTED_TO_data_pattern_generator_0_pattern_out_data,    --                                         .data
			data_pattern_generator_0_pattern_out_clk_clk => CONNECTED_TO_data_pattern_generator_0_pattern_out_clk_clk, -- data_pattern_generator_0_pattern_out_clk.clk
			reset_reset_n                                => CONNECTED_TO_reset_reset_n,                                --                                    reset.reset_n
			user_dipsw_external_connection_export        => CONNECTED_TO_user_dipsw_external_connection_export,        --           user_dipsw_external_connection.export
			user_led_external_connection_export          => CONNECTED_TO_user_led_external_connection_export,          --             user_led_external_connection.export
			user_pb_external_connection_export           => CONNECTED_TO_user_pb_external_connection_export            --              user_pb_external_connection.export
		);

