	hdmi_qsys u0 (
		.alt_vip_cl_cvo_0_clocked_video_vid_data      (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_data>),      //    alt_vip_cl_cvo_0_clocked_video.vid_data
		.alt_vip_cl_cvo_0_clocked_video_underflow     (<connected-to-alt_vip_cl_cvo_0_clocked_video_underflow>),     //                                  .underflow
		.alt_vip_cl_cvo_0_clocked_video_vid_datavalid (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_datavalid>), //                                  .vid_datavalid
		.alt_vip_cl_cvo_0_clocked_video_vid_v_sync    (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_v_sync>),    //                                  .vid_v_sync
		.alt_vip_cl_cvo_0_clocked_video_vid_h_sync    (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_h_sync>),    //                                  .vid_h_sync
		.alt_vip_cl_cvo_0_clocked_video_vid_f         (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_f>),         //                                  .vid_f
		.alt_vip_cl_cvo_0_clocked_video_vid_h         (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_h>),         //                                  .vid_h
		.alt_vip_cl_cvo_0_clocked_video_vid_v         (<connected-to-alt_vip_cl_cvo_0_clocked_video_vid_v>),         //                                  .vid_v
		.altpll_0_locked_conduit_export               (<connected-to-altpll_0_locked_conduit_export>),               //           altpll_0_locked_conduit.export
		.clk_clk                                      (<connected-to-clk_clk>),                                      //                               clk.clk
		.disp_refclk_out_clk_clk                      (<connected-to-disp_refclk_out_clk_clk>),                      //               disp_refclk_out_clk.clk
		.hdmi_tx_int_n_external_connection_export     (<connected-to-hdmi_tx_int_n_external_connection_export>),     // hdmi_tx_int_n_external_connection.export
		.opencores_i2c_0_export_0_scl_pad_io          (<connected-to-opencores_i2c_0_export_0_scl_pad_io>),          //          opencores_i2c_0_export_0.scl_pad_io
		.opencores_i2c_0_export_0_sda_pad_io          (<connected-to-opencores_i2c_0_export_0_sda_pad_io>),          //                                  .sda_pad_io
		.reset_reset_n                                (<connected-to-reset_reset_n>)                                 //                             reset.reset_n
	);

