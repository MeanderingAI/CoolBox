#set pll_afi_clock $pins(pll_afi_clock)
#create_generated_clock -name slow_clk_a -source $pll_afi_clock  -divide_by 32 {*|master_driver_msgdma_*|slow_clk_int[4]}
