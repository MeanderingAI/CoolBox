--Copyright (C) 2018-2024 Intel Corporation
--
-- This code and the related documents are Intel copyrighted materials, and
-- your use of them is governed by the express license under which they were
--provided to you ("License"). Unless the License provides otherwise, you may
--not use, modify, copy, publish, distribute, disclose or transmit this
--code or the related documents without Intel's prior written permission.
--This code and the related documents are provided as is, with no express
-- or implied warranties, other than those that are expressly stated in the
-- License.

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_UNSIGNED.all;

						
entity product_info is
	port (
		clk: in std_logic;
		reset_n : in std_logic;
		
		chipselect_n : in std_logic; -- chip select signal
		read_n : in std_logic; -- output enable
		av_address : in std_logic_vector(1 downto 0);
		av_data_read : out std_logic_vector(31 downto 0)
		
	);
end product_info;

architecture rtl of product_info is
--	constant sof : std_logic_vector(31 downto 0):=x"30414443"; -- 0ADC project
--	constant sof : std_logic_vector(31 downto 0):=x"4750494F"; -- GPIO project
--	constant sof : std_logic_vector(31 downto 0):=x"56494445"; -- VIDE project
--	constant sof : std_logic_vector(31 downto 0):=x"48444D49"; -- HDMI project
--	constant sof : std_logic_vector(31 downto 0):=x"48534D43"; -- HSMC project
--	constant sof : std_logic_vector(31 downto 0):=x"51445232"; -- QDR2 project
--	constant sof : std_logic_vector(31 downto 0):=x"44445233"; -- DDR3 project
--	constant sof : std_logic_vector(31 downto 0):=x"44445232"; -- DDR2 project

				constant sof : std_logic_vector(31 downto 0):=x"48444D49"; -- HDMI project
                constant board : std_logic_vector(31 downto 0):=x"4D413038"; -- MA08
                constant product : std_logic_vector(31 downto 0):=x"000A100C"; -- 44165
                constant version : std_logic_vector(31 downto 0):=x"00000001"; -- to indicate this is dev1
begin

	process(reset_n, clk)begin
		if(reset_n = '0')then
			av_data_read <= (others => '0');
		elsif(clk'event and clk = '1')then
			if(chipselect_n = '0' and read_n = '0')then
				case av_address is
					when "00" => av_data_read <= product;
					when "01" => av_data_read <= board;
					when "10" => av_data_read <= sof;
					when "11" => av_data_read <= version;
				end case;
			end if;
		end if;
	end process;
end rtl;

