
#How to get correct LOCAL_DATA_WORDS which is a key factor for performance calculation:

LOCAL_DATA_WORDS = Avalon_Bus_Data_Width/8

E.g. Avalon_Bus_Data_Width = 64;