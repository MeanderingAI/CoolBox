#**************************************************************
# Create Clock
#**************************************************************

derive_pll_clocks


#JTAG Signal Constraints constrain the TCK port, assuming a 10MHz JTAG clock and 3ns delays
create_clock -name {altera_reserved_tck} -period 41.667 [get_ports { altera_reserved_tck }]
set_input_delay -clock altera_reserved_tck -clock_fall -max 5 [get_ports altera_reserved_tdi]
set_input_delay -clock altera_reserved_tck -clock_fall -max 5 [get_ports altera_reserved_tms]
set_output_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tdo]


#create clock
create_clock -name {clk_ddr3_100_p} -period 10.000 {clk_ddr3_100_p}
create_clock -name {clk_50_max10} -period 20.000 {clk_50_max10}
create_clock -name {clk_25_max10} -period 40.000 {clk_25_max10}

create_clock -name {data1_38} -period 6.667 -waveform { 0.000 3.333 } [get_registers {q_sys:u0_q_sys|q_sys_mSGDMA_0:msgdma_0|q_sys_mSGDMA_0_mm_interconnect_0:mm_interconnect_0|altera_avalon_st_pipeline_stage:agent_pipeline_010|altera_avalon_st_pipeline_base:core|data1[38]}]


#create generate clock

create_generated_clock -name {slow_clk} -source [get_ports {clk_50_max10}] -divide_by 2 -master_clock {clk_50_max10} [get_registers {q_sys:u0_q_sys|q_sys_mSGDMA_0:msgdma_0|freq_counter:freq_counter_0|slow_clk}] 
create_generated_clock -name {slow_clk_int} -source [get_ports {clk_50_max10}] -divide_by 32 -master_clock {clk_50_max10} [get_registers {q_sys:u0_q_sys|master_driver_msgdma:master_driver_msgdma_0|slow_clk_int[4]}] 


#clock uncertainty is required
derive_clock_uncertainty


#set false path
set_false_path  -from  [get_clocks *]  -to  [get_clocks {slow_clk}]
set_false_path  -from  [get_clocks {slow_clk}]  -to  [get_clocks *]
set_false_path  -from  [get_clocks *]  -to  [get_clocks {slow_clk_int}]
set_false_path  -from  [get_clocks {slow_clk_int}]  -to  [get_clocks *]
set_false_path  -from  [get_clocks *]  -to  [get_clocks {data1_38}]
set_false_path  -from  [get_clocks {data1_38}]  -to  [get_clocks *]

set_false_path -to  [get_ports {ddr3_ck[0]}]
set_false_path -to  [get_ports {ddr3_ck_n[0]}]
set_false_path -from [get_keepers {ddr3_dq[*]}]
set_false_path -to [get_keepers {ddr3_dqs_n[*]}]
set_false_path -to [get_keepers {ddr3_reset_n}]

set_false_path -from [get_ports {fpga_resetn}] 
set_false_path -from [get_ports {user_dipsw[*]}] 
set_false_path -from [get_ports {user_pb[*]}] 
set_false_path -to [get_ports {user_led[*]}]

set_false_path -from * -to {sld_signaltap:auto_signaltap_0|*}
set_false_path -from {sld_signaltap:auto_signaltap_0|*} -to *

