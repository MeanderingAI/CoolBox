
module hsmc_qsys (
	clk_clk,
	data_pattern_checker_0_pattern_in_valid,
	data_pattern_checker_0_pattern_in_ready,
	data_pattern_checker_0_pattern_in_data,
	data_pattern_checker_0_pattern_in_clk_clk,
	data_pattern_generator_0_pattern_out_valid,
	data_pattern_generator_0_pattern_out_ready,
	data_pattern_generator_0_pattern_out_data,
	data_pattern_generator_0_pattern_out_clk_clk,
	reset_reset_n,
	user_dipsw_external_connection_export,
	user_led_external_connection_export,
	user_pb_external_connection_export);	

	input		clk_clk;
	input		data_pattern_checker_0_pattern_in_valid;
	output		data_pattern_checker_0_pattern_in_ready;
	input	[31:0]	data_pattern_checker_0_pattern_in_data;
	input		data_pattern_checker_0_pattern_in_clk_clk;
	output		data_pattern_generator_0_pattern_out_valid;
	input		data_pattern_generator_0_pattern_out_ready;
	output	[31:0]	data_pattern_generator_0_pattern_out_data;
	input		data_pattern_generator_0_pattern_out_clk_clk;
	input		reset_reset_n;
	input	[4:0]	user_dipsw_external_connection_export;
	output	[4:0]	user_led_external_connection_export;
	input	[3:0]	user_pb_external_connection_export;
endmodule
