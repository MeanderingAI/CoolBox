/*******************************************************************************
*
* Copyright (C) 2018-2024 Intel Corporation
* 
* This code and the related documents are Intel copyrighted materials, and 
* your use of them is governed by the express license under which they were 
* provided to you ("License"). Unless the License provides otherwise, you may 
* not use, modify, copy, publish, distribute, disclose or transmit this 
* code or the related documents without Intel's prior written permission.
*
* This code and the related documents are provided as is, with no express 
* or implied warranties, other than those that are expressly stated in the 
* License.
*
*******************************************************************************/

`timescale 1 ps / 1 ps
module adc (
		//Reset and Clocks
		input          clk_ddr3_100_p,
		input          clk_50_max10,
		input          clk_25_max10,
		input          clk_lvds_125_p,
		input          clk_10_adc,
		input          fpga_resetn,
		
		//LED PB DIPSW
		output [4:0]   user_led,
		input  [3:0]   user_pb,
		input  [4:0]   user_dipsw,
		
		//DAC
		output         dac_sync,
		output         dac_sclk,
		output         dac_din
		
		//ADC
		//input  [8:1] adc1in,
		//input  [8:1] adc2in
	);

parameter             SLAVES        = 1;  // Slave target number
parameter             DATA_WIDTH    = 24; // Data width
parameter             CLK_DIV       = 0;  // system clock cycles per 1/2 period of sclk, CLK_DIV ==0 -> no division
parameter             ADDR          = 0;  // address of slave

wire                  clk_10_adc_ref;
wire                  pll_locked;

wire                  cpol/* synthesis keep */;     // SPI clock polarity setting
wire                  cpha/* synthesis keep */;     // SPI clock phase setting
wire                  enable/* synthesis keep */;   // H: latches in settings, address, and data to initiate a transaction, L: no transaction is initiated.
wire                  cont/* synthesis keep */;     // Continuous mode flag
wire   [17:0]         dac_ctrl/* synthesis keep */; // DAC control and data
wire   [23:0]         tx_data;                      // SPI Tx data

assign      cpol      = 1'b1;
assign      cpha      = 1'b0;
assign      enable    = dac_ctrl[17];
assign      cont      = dac_ctrl[16];
assign      tx_data   = {6'b000000, 2'b00, dac_ctrl[15:0]}; // reserve bits, operation mode setting (default: normal mode) and DAC data

adc_pll     adc_pll_u0  (
                        .areset                                 (!fpga_resetn    ),
                        .inclk0                                 (clk_10_adc      ),
                        .c0                                     (clk_10_adc_ref  ),
                        .locked                                 (pll_locked      )
                        );

adc_qsys    adc_qsys_u0 (
                        .clk_50m_clk                            (clk_50_max10    ), //                      clk_50m.clk
                        .reset_50m_reset_n                      (fpga_resetn     ), //                    reset_50m.reset_n
                        .clk_adc_ref_clk                        (clk_10_adc_ref  ), //                  clk_adc_ref.clk
                        .reset_adc_ref_reset_n                  (fpga_resetn     ), //                reset_adc_ref.reset_n
                        .modular_adc_0_adc_pll_locked_export    (pll_locked      ), // modular_adc_0_adc_pll_locked.export
                        .modular_adc_1_adc_pll_locked_export    (pll_locked      ), // modular_adc_1_adc_pll_locked.export
                        .dac_ctrl_external_connection_export    (dac_ctrl        )  // dac_ctrl_external_connection.export
                        );

spi_master              #(
                        .slaves                                 (SLAVES          ), // 
                        .d_width                                (DATA_WIDTH      )  // 
                        )
                        spi_master_dac
                        (
                        .clock                                  (clk_25_max10    ), // system clock
                        .reset_n                                (fpga_resetn     ), // asynchronous reset
                        .enable                                 (enable          ), // initiate transaction
                        .cpol                                   (cpol            ), // spi clock polarity
                        .cpha                                   (cpha            ), // spi clock phase
                        .cont                                   (cont            ), // continuous mode command
                        .clk_div                                (CLK_DIV         ), // system clock cycles per 1/2 period of sclk
                        .addr                                   (ADDR            ), // address of slave
                        .tx_data                                (tx_data         ), // data to transmit
                        //.miso                                 (                ), // master in, slave out
                        .sclk                                   (dac_sclk        ), // spi clock
                        .ss_n                                   (dac_sync        ), // slave select
                        .mosi                                   (dac_din         )  // master out, slave in
                        //.busy                                 (                ), // busy / data ready signal
                        //.rx_data                              (                )  // data received
                        );

assign user_led  = {4'b1111, !pll_locked};

endmodule
