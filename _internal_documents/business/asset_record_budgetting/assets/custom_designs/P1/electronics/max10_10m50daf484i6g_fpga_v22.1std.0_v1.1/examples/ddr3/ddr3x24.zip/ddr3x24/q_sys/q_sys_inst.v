	q_sys u0 (
		.master_driver_msgdma_0_conduit_end_error_mon  (<connected-to-master_driver_msgdma_0_conduit_end_error_mon>),  //  master_driver_msgdma_0_conduit_end.error_mon
		.master_driver_msgdma_0_conduit_end_status_mon (<connected-to-master_driver_msgdma_0_conduit_end_status_mon>), //                                    .status_mon
		.memory_mem_a                                  (<connected-to-memory_mem_a>),                                  //                              memory.mem_a
		.memory_mem_ba                                 (<connected-to-memory_mem_ba>),                                 //                                    .mem_ba
		.memory_mem_ck                                 (<connected-to-memory_mem_ck>),                                 //                                    .mem_ck
		.memory_mem_ck_n                               (<connected-to-memory_mem_ck_n>),                               //                                    .mem_ck_n
		.memory_mem_cke                                (<connected-to-memory_mem_cke>),                                //                                    .mem_cke
		.memory_mem_cs_n                               (<connected-to-memory_mem_cs_n>),                               //                                    .mem_cs_n
		.memory_mem_dm                                 (<connected-to-memory_mem_dm>),                                 //                                    .mem_dm
		.memory_mem_ras_n                              (<connected-to-memory_mem_ras_n>),                              //                                    .mem_ras_n
		.memory_mem_cas_n                              (<connected-to-memory_mem_cas_n>),                              //                                    .mem_cas_n
		.memory_mem_we_n                               (<connected-to-memory_mem_we_n>),                               //                                    .mem_we_n
		.memory_mem_reset_n                            (<connected-to-memory_mem_reset_n>),                            //                                    .mem_reset_n
		.memory_mem_dq                                 (<connected-to-memory_mem_dq>),                                 //                                    .mem_dq
		.memory_mem_dqs                                (<connected-to-memory_mem_dqs>),                                //                                    .mem_dqs
		.memory_mem_dqs_n                              (<connected-to-memory_mem_dqs_n>),                              //                                    .mem_dqs_n
		.memory_mem_odt                                (<connected-to-memory_mem_odt>),                                //                                    .mem_odt
		.msgdma_0_cal_fail_mon_export                  (<connected-to-msgdma_0_cal_fail_mon_export>),                  //               msgdma_0_cal_fail_mon.export
		.msgdma_0_cal_success_mon_export               (<connected-to-msgdma_0_cal_success_mon_export>),               //            msgdma_0_cal_success_mon.export
		.msgdma_0_status_mon_0_init_done_mon_export    (<connected-to-msgdma_0_status_mon_0_init_done_mon_export>),    // msgdma_0_status_mon_0_init_done_mon.export
		.refclk_clock_bridge_in_clk_clk                (<connected-to-refclk_clock_bridge_in_clk_clk>),                //          refclk_clock_bridge_in_clk.clk
		.reset_reset_n                                 (<connected-to-reset_reset_n>),                                 //                               reset.reset_n
		.sys_clk_clk                                   (<connected-to-sys_clk_clk>)                                    //                             sys_clk.clk
	);

