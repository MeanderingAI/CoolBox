	component q_sys is
		port (
			master_driver_msgdma_0_conduit_end_error_mon  : out   std_logic;                                        -- error_mon
			master_driver_msgdma_0_conduit_end_status_mon : out   std_logic;                                        -- status_mon
			memory_mem_a                                  : out   std_logic_vector(12 downto 0);                    -- mem_a
			memory_mem_ba                                 : out   std_logic_vector(2 downto 0);                     -- mem_ba
			memory_mem_ck                                 : inout std_logic_vector(0 downto 0)  := (others => 'X'); -- mem_ck
			memory_mem_ck_n                               : inout std_logic_vector(0 downto 0)  := (others => 'X'); -- mem_ck_n
			memory_mem_cke                                : out   std_logic_vector(0 downto 0);                     -- mem_cke
			memory_mem_cs_n                               : out   std_logic_vector(0 downto 0);                     -- mem_cs_n
			memory_mem_dm                                 : out   std_logic_vector(2 downto 0);                     -- mem_dm
			memory_mem_ras_n                              : out   std_logic_vector(0 downto 0);                     -- mem_ras_n
			memory_mem_cas_n                              : out   std_logic_vector(0 downto 0);                     -- mem_cas_n
			memory_mem_we_n                               : out   std_logic_vector(0 downto 0);                     -- mem_we_n
			memory_mem_reset_n                            : out   std_logic;                                        -- mem_reset_n
			memory_mem_dq                                 : inout std_logic_vector(23 downto 0) := (others => 'X'); -- mem_dq
			memory_mem_dqs                                : inout std_logic_vector(2 downto 0)  := (others => 'X'); -- mem_dqs
			memory_mem_dqs_n                              : inout std_logic_vector(2 downto 0)  := (others => 'X'); -- mem_dqs_n
			memory_mem_odt                                : out   std_logic_vector(0 downto 0);                     -- mem_odt
			msgdma_0_cal_fail_mon_export                  : out   std_logic;                                        -- export
			msgdma_0_cal_success_mon_export               : out   std_logic;                                        -- export
			msgdma_0_status_mon_0_init_done_mon_export    : out   std_logic;                                        -- export
			refclk_clock_bridge_in_clk_clk                : in    std_logic                     := 'X';             -- clk
			reset_reset_n                                 : in    std_logic                     := 'X';             -- reset_n
			sys_clk_clk                                   : in    std_logic                     := 'X'              -- clk
		);
	end component q_sys;

	u0 : component q_sys
		port map (
			master_driver_msgdma_0_conduit_end_error_mon  => CONNECTED_TO_master_driver_msgdma_0_conduit_end_error_mon,  --  master_driver_msgdma_0_conduit_end.error_mon
			master_driver_msgdma_0_conduit_end_status_mon => CONNECTED_TO_master_driver_msgdma_0_conduit_end_status_mon, --                                    .status_mon
			memory_mem_a                                  => CONNECTED_TO_memory_mem_a,                                  --                              memory.mem_a
			memory_mem_ba                                 => CONNECTED_TO_memory_mem_ba,                                 --                                    .mem_ba
			memory_mem_ck                                 => CONNECTED_TO_memory_mem_ck,                                 --                                    .mem_ck
			memory_mem_ck_n                               => CONNECTED_TO_memory_mem_ck_n,                               --                                    .mem_ck_n
			memory_mem_cke                                => CONNECTED_TO_memory_mem_cke,                                --                                    .mem_cke
			memory_mem_cs_n                               => CONNECTED_TO_memory_mem_cs_n,                               --                                    .mem_cs_n
			memory_mem_dm                                 => CONNECTED_TO_memory_mem_dm,                                 --                                    .mem_dm
			memory_mem_ras_n                              => CONNECTED_TO_memory_mem_ras_n,                              --                                    .mem_ras_n
			memory_mem_cas_n                              => CONNECTED_TO_memory_mem_cas_n,                              --                                    .mem_cas_n
			memory_mem_we_n                               => CONNECTED_TO_memory_mem_we_n,                               --                                    .mem_we_n
			memory_mem_reset_n                            => CONNECTED_TO_memory_mem_reset_n,                            --                                    .mem_reset_n
			memory_mem_dq                                 => CONNECTED_TO_memory_mem_dq,                                 --                                    .mem_dq
			memory_mem_dqs                                => CONNECTED_TO_memory_mem_dqs,                                --                                    .mem_dqs
			memory_mem_dqs_n                              => CONNECTED_TO_memory_mem_dqs_n,                              --                                    .mem_dqs_n
			memory_mem_odt                                => CONNECTED_TO_memory_mem_odt,                                --                                    .mem_odt
			msgdma_0_cal_fail_mon_export                  => CONNECTED_TO_msgdma_0_cal_fail_mon_export,                  --               msgdma_0_cal_fail_mon.export
			msgdma_0_cal_success_mon_export               => CONNECTED_TO_msgdma_0_cal_success_mon_export,               --            msgdma_0_cal_success_mon.export
			msgdma_0_status_mon_0_init_done_mon_export    => CONNECTED_TO_msgdma_0_status_mon_0_init_done_mon_export,    -- msgdma_0_status_mon_0_init_done_mon.export
			refclk_clock_bridge_in_clk_clk                => CONNECTED_TO_refclk_clock_bridge_in_clk_clk,                --          refclk_clock_bridge_in_clk.clk
			reset_reset_n                                 => CONNECTED_TO_reset_reset_n,                                 --                               reset.reset_n
			sys_clk_clk                                   => CONNECTED_TO_sys_clk_clk                                    --                             sys_clk.clk
		);

