/*******************************************************************************
*
* Copyright (C) 2018-2024 Intel Corporation
* 
* This code and the related documents are Intel copyrighted materials, and 
* your use of them is governed by the express license under which they were 
* provided to you ("License"). Unless the License provides otherwise, you may 
* not use, modify, copy, publish, distribute, disclose or transmit this 
* code or the related documents without Intel's prior written permission.
*
* This code and the related documents are provided as is, with no express 
* or implied warranties, other than those that are expressly stated in the 
* License.
*
*******************************************************************************/

`timescale 1ns / 100ps

module  filter_circuit #(
        parameter	         FILTER_WIDTH = 4, // even number: 2, 4, 6, 8 ...
        parameter            INIT_BIT     = 1
        )
        (
         input   wire        i_clk_rst       , // reset
         input   wire        i_clk           , // clock
         input   wire        i_framein       , // input
         output  wire        o_frameout        // output
         );

//--------------------------------------------------
// Signal defination
//--------------------------------------------------

wire                         initbit    ; // 
reg      [FILTER_WIDTH-1:0]  fr_shifter ; // 
reg                          frameout   ; // 
wire                         fr_posedge ; // 
wire                         fr_negedge ; // 

//--------------------------------------------------
// Main function body
//--------------------------------------------------

// Output assignments
assign o_frameout = frameout;

// input posedge/negedge detection
assign fr_posedge = (&(~fr_shifter[FILTER_WIDTH-1:FILTER_WIDTH/2])) && (&(fr_shifter[FILTER_WIDTH/2-1:0])); // posedge detection
assign fr_negedge = (&(fr_shifter[FILTER_WIDTH-1:FILTER_WIDTH/2])) && (&(~fr_shifter[FILTER_WIDTH/2-1:0])); // negedge detection

////////////////////////////////////////////////////////
// Left shifter control
always @(posedge i_clk or posedge i_clk_rst)
begin
  if(i_clk_rst)
    fr_shifter <= {FILTER_WIDTH{1'b0}};
  else
    fr_shifter <= {fr_shifter[FILTER_WIDTH-2:0], i_framein};
end

////////////////////////////////////////////////////////
// Filter output control
assign initbit = (INIT_BIT == 1) ? 1'b1 : 1'b0;

always @(posedge i_clk or posedge i_clk_rst)
begin
  if(i_clk_rst)
    frameout <= initbit;
  else if(fr_posedge)
    frameout <= 1'b1;
  else if(fr_negedge)
    frameout <= 1'b0;
  else
    frameout <= frameout;
end

endmodule
//------------------------------------------------------------------------------
// end of file
//------------------------------------------------------------------------------