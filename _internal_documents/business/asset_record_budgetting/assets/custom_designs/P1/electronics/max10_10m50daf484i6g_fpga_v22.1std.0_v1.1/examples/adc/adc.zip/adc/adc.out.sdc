## Generated SDC file "adc.out.sdc"

## Copyright (C) 1991-2014 Altera Corporation. All rights reserved.
## Your use of Altera Corporation's design tools, logic functions 
## and other software and tools, and its AMPP partner logic 
## functions, and any output files from any of the foregoing 
## (including device programming or simulation files), and any 
## associated documentation or information are expressly subject 
## to the terms and conditions of the Altera Program License 
## Subscription Agreement, the Altera Quartus II License Agreement,
## the Altera MegaCore Function License Agreement, or other 
## applicable license agreement, including, without limitation, 
## that your use is for the sole purpose of programming logic 
## devices manufactured by Altera and sold by Altera or its 
## authorized distributors.  Please refer to the applicable 
## agreement for further details.


## VENDOR  "Altera"
## PROGRAM "Quartus II"
## VERSION "Version 14.0.1 Build 204 08/06/2014 SJ Full Version"

## DATE    "Wed Aug 13 09:49:10 2014"

##
## DEVICE  "10M50DAF484C6GES"
##


#**************************************************************
# Time Information
#**************************************************************

set_time_format -unit ns -decimal_places 3



#**************************************************************
# Create Clock
#**************************************************************

create_clock -name {altera_reserved_tck} -period 40.800 -waveform { 0.000 20.400 } [get_ports { altera_reserved_tck }]
create_clock -name {clk_50_max10} -period 20.000 -waveform { 0.000 10.000 } [get_ports {clk_50_max10}]
create_clock -name {clk_10_adc} -period 100.000 -waveform { 0.000 50.000 } [get_ports {clk_10_adc}]
create_clock -name {clk_25_max10} -period 40.000 -waveform { 0.000 20.000 } [get_ports {clk_25_max10}]

#**************************************************************
# Create Generated Clock
#**************************************************************

derive_pll_clocks
create_generated_clock -name {adc_pll_u0|altpll_component|auto_generated|pll1|clk[0]} -source [get_pins {adc_pll_u0|altpll_component|auto_generated|pll1|inclk[0]}] -duty_cycle 50.000 -multiply_by 1 -master_clock {clk_10_adc} [get_pins {adc_pll_u0|altpll_component|auto_generated|pll1|clk[0]}] 

create_generated_clock -name sclk_div -source [get_ports {clk_25_max10}] -divide_by 2 [get_nets {spi_master:spi_master_dac|sclk}]
create_generated_clock -name dac_sclk -source [get_nets {spi_master:spi_master_dac|sclk}] [get_ports {dac_sclk}]

#**************************************************************
# Set Clock Latency
#**************************************************************


#**************************************************************
# Set Clock Uncertainty
#**************************************************************

set_clock_uncertainty -rise_from [get_clocks {clk_50_max10}] -rise_to [get_clocks {clk_50_max10}]  0.020  
set_clock_uncertainty -rise_from [get_clocks {clk_50_max10}] -fall_to [get_clocks {clk_50_max10}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {clk_50_max10}] -rise_to [get_clocks {clk_50_max10}]  0.020  
set_clock_uncertainty -fall_from [get_clocks {clk_50_max10}] -fall_to [get_clocks {clk_50_max10}]  0.020  

derive_clock_uncertainty

#**************************************************************
# Set Input Delay
#**************************************************************

set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tdi]
set_input_delay -clock altera_reserved_tck 5 [get_ports altera_reserved_tms]

#**************************************************************
# Set Output Delay
#**************************************************************

set_output_delay -clock altera_reserved_tck -clock_fall -max 5 [get_ports altera_reserved_tdo]

set_output_delay -clock dac_sclk -clock_fall -max 5 [get_ports {dac_din dac_sync}]
set_output_delay -clock dac_sclk -clock_fall -min -4.5 [get_ports {dac_din dac_sync}]

#**************************************************************
# Set Clock Groups
#**************************************************************

set_clock_groups -asynchronous -group [get_clocks {altera_reserved_tck}]
set_clock_groups -asynchronous -group [get_clocks {dac_sclk}]

#**************************************************************
# Set False Path
#**************************************************************

set_false_path -from [get_ports {fpga_resetn}]
set_false_path -from [get_ports {user_dipsw[*]}]
set_false_path -from [get_ports {user_pb[*]}]
set_false_path -to [get_ports {user_led[*]}]
set_false_path -to [get_ports {dac_sclk}]

#**************************************************************
# Set Multicycle Path
#**************************************************************



#**************************************************************
# Set Maximum Delay
#**************************************************************



#**************************************************************
# Set Minimum Delay
#**************************************************************



#**************************************************************
# Set Input Transition
#**************************************************************

