	component mSGDMA is
		port (
			cal_fail_mon_export               : out std_logic;                                         -- export
			cal_success_mon_export            : out std_logic;                                         -- export
			clk_clk                           : in  std_logic                      := 'X';             -- clk
			clk_0_clk                         : in  std_logic                      := 'X';             -- clk
			dispatcher_read_csr_irq_irq       : out std_logic;                                         -- irq
			dispatcher_write_csr_irq_irq      : out std_logic;                                         -- irq
			dma_read_master_address           : out std_logic_vector(31 downto 0);                     -- address
			dma_read_master_read              : out std_logic;                                         -- read
			dma_read_master_byteenable        : out std_logic_vector(15 downto 0);                     -- byteenable
			dma_read_master_readdata          : in  std_logic_vector(127 downto 0) := (others => 'X'); -- readdata
			dma_read_master_waitrequest       : in  std_logic                      := 'X';             -- waitrequest
			dma_read_master_readdatavalid     : in  std_logic                      := 'X';             -- readdatavalid
			dma_read_master_burstcount        : out std_logic_vector(5 downto 0);                      -- burstcount
			dma_write_master_address          : out std_logic_vector(31 downto 0);                     -- address
			dma_write_master_write            : out std_logic;                                         -- write
			dma_write_master_byteenable       : out std_logic_vector(15 downto 0);                     -- byteenable
			dma_write_master_writedata        : out std_logic_vector(127 downto 0);                    -- writedata
			dma_write_master_waitrequest      : in  std_logic                      := 'X';             -- waitrequest
			dma_write_master_burstcount       : out std_logic_vector(5 downto 0);                      -- burstcount
			eset_source_reset_n               : out std_logic;                                         -- reset_n
			mm_bridge_slv_waitrequest         : out std_logic;                                         -- waitrequest
			mm_bridge_slv_readdata            : out std_logic_vector(31 downto 0);                     -- readdata
			mm_bridge_slv_readdatavalid       : out std_logic;                                         -- readdatavalid
			mm_bridge_slv_burstcount          : in  std_logic_vector(6 downto 0)   := (others => 'X'); -- burstcount
			mm_bridge_slv_writedata           : in  std_logic_vector(31 downto 0)  := (others => 'X'); -- writedata
			mm_bridge_slv_address             : in  std_logic_vector(19 downto 0)  := (others => 'X'); -- address
			mm_bridge_slv_write               : in  std_logic                      := 'X';             -- write
			mm_bridge_slv_read                : in  std_logic                      := 'X';             -- read
			mm_bridge_slv_byteenable          : in  std_logic_vector(3 downto 0)   := (others => 'X'); -- byteenable
			mm_bridge_slv_debugaccess         : in  std_logic                      := 'X';             -- debugaccess
			reset_reset_n                     : in  std_logic                      := 'X';             -- reset_n
			reset_0_reset_n                   : in  std_logic                      := 'X';             -- reset_n
			status_mon_0_init_done_mon_export : out std_logic;                                         -- export
			status_mon_in_local_init_done     : in  std_logic                      := 'X';             -- local_init_done
			status_mon_in_local_cal_success   : in  std_logic                      := 'X';             -- local_cal_success
			status_mon_in_local_cal_fail      : in  std_logic                      := 'X'              -- local_cal_fail
		);
	end component mSGDMA;

	u0 : component mSGDMA
		port map (
			cal_fail_mon_export               => CONNECTED_TO_cal_fail_mon_export,               --               cal_fail_mon.export
			cal_success_mon_export            => CONNECTED_TO_cal_success_mon_export,            --            cal_success_mon.export
			clk_clk                           => CONNECTED_TO_clk_clk,                           --                        clk.clk
			clk_0_clk                         => CONNECTED_TO_clk_0_clk,                         --                      clk_0.clk
			dispatcher_read_csr_irq_irq       => CONNECTED_TO_dispatcher_read_csr_irq_irq,       --    dispatcher_read_csr_irq.irq
			dispatcher_write_csr_irq_irq      => CONNECTED_TO_dispatcher_write_csr_irq_irq,      --   dispatcher_write_csr_irq.irq
			dma_read_master_address           => CONNECTED_TO_dma_read_master_address,           --            dma_read_master.address
			dma_read_master_read              => CONNECTED_TO_dma_read_master_read,              --                           .read
			dma_read_master_byteenable        => CONNECTED_TO_dma_read_master_byteenable,        --                           .byteenable
			dma_read_master_readdata          => CONNECTED_TO_dma_read_master_readdata,          --                           .readdata
			dma_read_master_waitrequest       => CONNECTED_TO_dma_read_master_waitrequest,       --                           .waitrequest
			dma_read_master_readdatavalid     => CONNECTED_TO_dma_read_master_readdatavalid,     --                           .readdatavalid
			dma_read_master_burstcount        => CONNECTED_TO_dma_read_master_burstcount,        --                           .burstcount
			dma_write_master_address          => CONNECTED_TO_dma_write_master_address,          --           dma_write_master.address
			dma_write_master_write            => CONNECTED_TO_dma_write_master_write,            --                           .write
			dma_write_master_byteenable       => CONNECTED_TO_dma_write_master_byteenable,       --                           .byteenable
			dma_write_master_writedata        => CONNECTED_TO_dma_write_master_writedata,        --                           .writedata
			dma_write_master_waitrequest      => CONNECTED_TO_dma_write_master_waitrequest,      --                           .waitrequest
			dma_write_master_burstcount       => CONNECTED_TO_dma_write_master_burstcount,       --                           .burstcount
			eset_source_reset_n               => CONNECTED_TO_eset_source_reset_n,               --                eset_source.reset_n
			mm_bridge_slv_waitrequest         => CONNECTED_TO_mm_bridge_slv_waitrequest,         --              mm_bridge_slv.waitrequest
			mm_bridge_slv_readdata            => CONNECTED_TO_mm_bridge_slv_readdata,            --                           .readdata
			mm_bridge_slv_readdatavalid       => CONNECTED_TO_mm_bridge_slv_readdatavalid,       --                           .readdatavalid
			mm_bridge_slv_burstcount          => CONNECTED_TO_mm_bridge_slv_burstcount,          --                           .burstcount
			mm_bridge_slv_writedata           => CONNECTED_TO_mm_bridge_slv_writedata,           --                           .writedata
			mm_bridge_slv_address             => CONNECTED_TO_mm_bridge_slv_address,             --                           .address
			mm_bridge_slv_write               => CONNECTED_TO_mm_bridge_slv_write,               --                           .write
			mm_bridge_slv_read                => CONNECTED_TO_mm_bridge_slv_read,                --                           .read
			mm_bridge_slv_byteenable          => CONNECTED_TO_mm_bridge_slv_byteenable,          --                           .byteenable
			mm_bridge_slv_debugaccess         => CONNECTED_TO_mm_bridge_slv_debugaccess,         --                           .debugaccess
			reset_reset_n                     => CONNECTED_TO_reset_reset_n,                     --                      reset.reset_n
			reset_0_reset_n                   => CONNECTED_TO_reset_0_reset_n,                   --                    reset_0.reset_n
			status_mon_0_init_done_mon_export => CONNECTED_TO_status_mon_0_init_done_mon_export, -- status_mon_0_init_done_mon.export
			status_mon_in_local_init_done     => CONNECTED_TO_status_mon_in_local_init_done,     --              status_mon_in.local_init_done
			status_mon_in_local_cal_success   => CONNECTED_TO_status_mon_in_local_cal_success,   --                           .local_cal_success
			status_mon_in_local_cal_fail      => CONNECTED_TO_status_mon_in_local_cal_fail       --                           .local_cal_fail
		);

