
module clk_ctrl (
	inclk,
	ena,
	outclk);	

	input		inclk;
	input		ena;
	output		outclk;
endmodule
