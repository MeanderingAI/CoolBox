	component hdmi_qsys is
		port (
			alt_vip_cl_cvo_0_clocked_video_vid_data      : out   std_logic_vector(23 downto 0);        -- vid_data
			alt_vip_cl_cvo_0_clocked_video_underflow     : out   std_logic;                            -- underflow
			alt_vip_cl_cvo_0_clocked_video_vid_datavalid : out   std_logic;                            -- vid_datavalid
			alt_vip_cl_cvo_0_clocked_video_vid_v_sync    : out   std_logic;                            -- vid_v_sync
			alt_vip_cl_cvo_0_clocked_video_vid_h_sync    : out   std_logic;                            -- vid_h_sync
			alt_vip_cl_cvo_0_clocked_video_vid_f         : out   std_logic;                            -- vid_f
			alt_vip_cl_cvo_0_clocked_video_vid_h         : out   std_logic;                            -- vid_h
			alt_vip_cl_cvo_0_clocked_video_vid_v         : out   std_logic;                            -- vid_v
			altpll_0_locked_conduit_export               : out   std_logic;                            -- export
			clk_clk                                      : in    std_logic                     := 'X'; -- clk
			disp_refclk_out_clk_clk                      : out   std_logic;                            -- clk
			hdmi_tx_int_n_external_connection_export     : in    std_logic                     := 'X'; -- export
			opencores_i2c_0_export_0_scl_pad_io          : inout std_logic                     := 'X'; -- scl_pad_io
			opencores_i2c_0_export_0_sda_pad_io          : inout std_logic                     := 'X'; -- sda_pad_io
			reset_reset_n                                : in    std_logic                     := 'X'  -- reset_n
		);
	end component hdmi_qsys;

	u0 : component hdmi_qsys
		port map (
			alt_vip_cl_cvo_0_clocked_video_vid_data      => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_data,      --    alt_vip_cl_cvo_0_clocked_video.vid_data
			alt_vip_cl_cvo_0_clocked_video_underflow     => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_underflow,     --                                  .underflow
			alt_vip_cl_cvo_0_clocked_video_vid_datavalid => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_datavalid, --                                  .vid_datavalid
			alt_vip_cl_cvo_0_clocked_video_vid_v_sync    => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_v_sync,    --                                  .vid_v_sync
			alt_vip_cl_cvo_0_clocked_video_vid_h_sync    => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_h_sync,    --                                  .vid_h_sync
			alt_vip_cl_cvo_0_clocked_video_vid_f         => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_f,         --                                  .vid_f
			alt_vip_cl_cvo_0_clocked_video_vid_h         => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_h,         --                                  .vid_h
			alt_vip_cl_cvo_0_clocked_video_vid_v         => CONNECTED_TO_alt_vip_cl_cvo_0_clocked_video_vid_v,         --                                  .vid_v
			altpll_0_locked_conduit_export               => CONNECTED_TO_altpll_0_locked_conduit_export,               --           altpll_0_locked_conduit.export
			clk_clk                                      => CONNECTED_TO_clk_clk,                                      --                               clk.clk
			disp_refclk_out_clk_clk                      => CONNECTED_TO_disp_refclk_out_clk_clk,                      --               disp_refclk_out_clk.clk
			hdmi_tx_int_n_external_connection_export     => CONNECTED_TO_hdmi_tx_int_n_external_connection_export,     -- hdmi_tx_int_n_external_connection.export
			opencores_i2c_0_export_0_scl_pad_io          => CONNECTED_TO_opencores_i2c_0_export_0_scl_pad_io,          --          opencores_i2c_0_export_0.scl_pad_io
			opencores_i2c_0_export_0_sda_pad_io          => CONNECTED_TO_opencores_i2c_0_export_0_sda_pad_io,          --                                  .sda_pad_io
			reset_reset_n                                => CONNECTED_TO_reset_reset_n                                 --                             reset.reset_n
		);

