
module gpio (
	adc1_out_external_connection_in_port,
	adc1_out_external_connection_out_port,
	adc2_in_external_connection_export,
	altpll_0_areset_conduit_export,
	altpll_0_locked_conduit_export,
	clk_50m_clk,
	dac_ctrl_external_connection_export,
	generic_quad_spi_controller_0_flash_dataout_conduit_dataout,
	generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out,
	generic_quad_spi_controller_0_flash_ncs_conduit_ncs,
	pmod_input_external_connection_export,
	pmod_output_external_connection_in_port,
	pmod_output_external_connection_out_port,
	reset_50m_reset_n,
	uart_0_external_connection_rxd,
	uart_0_external_connection_txd,
	usb_debug_master_0_usb_if_clk,
	usb_debug_master_0_usb_if_reset_n,
	usb_debug_master_0_usb_if_full,
	usb_debug_master_0_usb_if_empty,
	usb_debug_master_0_usb_if_wr_n,
	usb_debug_master_0_usb_if_rd_n,
	usb_debug_master_0_usb_if_oe_n,
	usb_debug_master_0_usb_if_data,
	usb_debug_master_0_usb_if_addr,
	usb_debug_master_0_usb_if_scl,
	usb_debug_master_0_usb_if_sda,
	user_dipsw_external_connection_export,
	user_led_external_connection_export,
	user_pb_external_connection_export);	

	input	[7:0]	adc1_out_external_connection_in_port;
	output	[7:0]	adc1_out_external_connection_out_port;
	input	[7:0]	adc2_in_external_connection_export;
	input		altpll_0_areset_conduit_export;
	output		altpll_0_locked_conduit_export;
	input		clk_50m_clk;
	output	[17:0]	dac_ctrl_external_connection_export;
	inout	[3:0]	generic_quad_spi_controller_0_flash_dataout_conduit_dataout;
	output		generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out;
	output	[0:0]	generic_quad_spi_controller_0_flash_ncs_conduit_ncs;
	input	[7:0]	pmod_input_external_connection_export;
	input	[7:0]	pmod_output_external_connection_in_port;
	output	[7:0]	pmod_output_external_connection_out_port;
	input		reset_50m_reset_n;
	input		uart_0_external_connection_rxd;
	output		uart_0_external_connection_txd;
	input		usb_debug_master_0_usb_if_clk;
	input		usb_debug_master_0_usb_if_reset_n;
	output		usb_debug_master_0_usb_if_full;
	output		usb_debug_master_0_usb_if_empty;
	input		usb_debug_master_0_usb_if_wr_n;
	input		usb_debug_master_0_usb_if_rd_n;
	input		usb_debug_master_0_usb_if_oe_n;
	inout	[7:0]	usb_debug_master_0_usb_if_data;
	inout	[1:0]	usb_debug_master_0_usb_if_addr;
	inout		usb_debug_master_0_usb_if_scl;
	inout		usb_debug_master_0_usb_if_sda;
	input	[4:0]	user_dipsw_external_connection_export;
	output	[4:0]	user_led_external_connection_export;
	input	[3:0]	user_pb_external_connection_export;
endmodule
