	component gpio is
		port (
			adc1_out_external_connection_in_port                          : in    std_logic_vector(7 downto 0)  := (others => 'X'); -- in_port
			adc1_out_external_connection_out_port                         : out   std_logic_vector(7 downto 0);                     -- out_port
			adc2_in_external_connection_export                            : in    std_logic_vector(7 downto 0)  := (others => 'X'); -- export
			altpll_0_areset_conduit_export                                : in    std_logic                     := 'X';             -- export
			altpll_0_locked_conduit_export                                : out   std_logic;                                        -- export
			clk_50m_clk                                                   : in    std_logic                     := 'X';             -- clk
			dac_ctrl_external_connection_export                           : out   std_logic_vector(17 downto 0);                    -- export
			generic_quad_spi_controller_0_flash_dataout_conduit_dataout   : inout std_logic_vector(3 downto 0)  := (others => 'X'); -- conduit_dataout
			generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out : out   std_logic;                                        -- conduit_dclk_out
			generic_quad_spi_controller_0_flash_ncs_conduit_ncs           : out   std_logic_vector(0 downto 0);                     -- conduit_ncs
			pmod_input_external_connection_export                         : in    std_logic_vector(7 downto 0)  := (others => 'X'); -- export
			pmod_output_external_connection_in_port                       : in    std_logic_vector(7 downto 0)  := (others => 'X'); -- in_port
			pmod_output_external_connection_out_port                      : out   std_logic_vector(7 downto 0);                     -- out_port
			reset_50m_reset_n                                             : in    std_logic                     := 'X';             -- reset_n
			uart_0_external_connection_rxd                                : in    std_logic                     := 'X';             -- rxd
			uart_0_external_connection_txd                                : out   std_logic;                                        -- txd
			usb_debug_master_0_usb_if_clk                                 : in    std_logic                     := 'X';             -- clk
			usb_debug_master_0_usb_if_reset_n                             : in    std_logic                     := 'X';             -- reset_n
			usb_debug_master_0_usb_if_full                                : out   std_logic;                                        -- full
			usb_debug_master_0_usb_if_empty                               : out   std_logic;                                        -- empty
			usb_debug_master_0_usb_if_wr_n                                : in    std_logic                     := 'X';             -- wr_n
			usb_debug_master_0_usb_if_rd_n                                : in    std_logic                     := 'X';             -- rd_n
			usb_debug_master_0_usb_if_oe_n                                : in    std_logic                     := 'X';             -- oe_n
			usb_debug_master_0_usb_if_data                                : inout std_logic_vector(7 downto 0)  := (others => 'X'); -- data
			usb_debug_master_0_usb_if_addr                                : inout std_logic_vector(1 downto 0)  := (others => 'X'); -- addr
			usb_debug_master_0_usb_if_scl                                 : inout std_logic                     := 'X';             -- scl
			usb_debug_master_0_usb_if_sda                                 : inout std_logic                     := 'X';             -- sda
			user_dipsw_external_connection_export                         : in    std_logic_vector(4 downto 0)  := (others => 'X'); -- export
			user_led_external_connection_export                           : out   std_logic_vector(4 downto 0);                     -- export
			user_pb_external_connection_export                            : in    std_logic_vector(3 downto 0)  := (others => 'X')  -- export
		);
	end component gpio;

	u0 : component gpio
		port map (
			adc1_out_external_connection_in_port                          => CONNECTED_TO_adc1_out_external_connection_in_port,                          --                 adc1_out_external_connection.in_port
			adc1_out_external_connection_out_port                         => CONNECTED_TO_adc1_out_external_connection_out_port,                         --                                             .out_port
			adc2_in_external_connection_export                            => CONNECTED_TO_adc2_in_external_connection_export,                            --                  adc2_in_external_connection.export
			altpll_0_areset_conduit_export                                => CONNECTED_TO_altpll_0_areset_conduit_export,                                --                      altpll_0_areset_conduit.export
			altpll_0_locked_conduit_export                                => CONNECTED_TO_altpll_0_locked_conduit_export,                                --                      altpll_0_locked_conduit.export
			clk_50m_clk                                                   => CONNECTED_TO_clk_50m_clk,                                                   --                                      clk_50m.clk
			dac_ctrl_external_connection_export                           => CONNECTED_TO_dac_ctrl_external_connection_export,                           --                 dac_ctrl_external_connection.export
			generic_quad_spi_controller_0_flash_dataout_conduit_dataout   => CONNECTED_TO_generic_quad_spi_controller_0_flash_dataout_conduit_dataout,   --  generic_quad_spi_controller_0_flash_dataout.conduit_dataout
			generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out => CONNECTED_TO_generic_quad_spi_controller_0_flash_dclk_out_conduit_dclk_out, -- generic_quad_spi_controller_0_flash_dclk_out.conduit_dclk_out
			generic_quad_spi_controller_0_flash_ncs_conduit_ncs           => CONNECTED_TO_generic_quad_spi_controller_0_flash_ncs_conduit_ncs,           --      generic_quad_spi_controller_0_flash_ncs.conduit_ncs
			pmod_input_external_connection_export                         => CONNECTED_TO_pmod_input_external_connection_export,                         --               pmod_input_external_connection.export
			pmod_output_external_connection_in_port                       => CONNECTED_TO_pmod_output_external_connection_in_port,                       --              pmod_output_external_connection.in_port
			pmod_output_external_connection_out_port                      => CONNECTED_TO_pmod_output_external_connection_out_port,                      --                                             .out_port
			reset_50m_reset_n                                             => CONNECTED_TO_reset_50m_reset_n,                                             --                                    reset_50m.reset_n
			uart_0_external_connection_rxd                                => CONNECTED_TO_uart_0_external_connection_rxd,                                --                   uart_0_external_connection.rxd
			uart_0_external_connection_txd                                => CONNECTED_TO_uart_0_external_connection_txd,                                --                                             .txd
			usb_debug_master_0_usb_if_clk                                 => CONNECTED_TO_usb_debug_master_0_usb_if_clk,                                 --                    usb_debug_master_0_usb_if.clk
			usb_debug_master_0_usb_if_reset_n                             => CONNECTED_TO_usb_debug_master_0_usb_if_reset_n,                             --                                             .reset_n
			usb_debug_master_0_usb_if_full                                => CONNECTED_TO_usb_debug_master_0_usb_if_full,                                --                                             .full
			usb_debug_master_0_usb_if_empty                               => CONNECTED_TO_usb_debug_master_0_usb_if_empty,                               --                                             .empty
			usb_debug_master_0_usb_if_wr_n                                => CONNECTED_TO_usb_debug_master_0_usb_if_wr_n,                                --                                             .wr_n
			usb_debug_master_0_usb_if_rd_n                                => CONNECTED_TO_usb_debug_master_0_usb_if_rd_n,                                --                                             .rd_n
			usb_debug_master_0_usb_if_oe_n                                => CONNECTED_TO_usb_debug_master_0_usb_if_oe_n,                                --                                             .oe_n
			usb_debug_master_0_usb_if_data                                => CONNECTED_TO_usb_debug_master_0_usb_if_data,                                --                                             .data
			usb_debug_master_0_usb_if_addr                                => CONNECTED_TO_usb_debug_master_0_usb_if_addr,                                --                                             .addr
			usb_debug_master_0_usb_if_scl                                 => CONNECTED_TO_usb_debug_master_0_usb_if_scl,                                 --                                             .scl
			usb_debug_master_0_usb_if_sda                                 => CONNECTED_TO_usb_debug_master_0_usb_if_sda,                                 --                                             .sda
			user_dipsw_external_connection_export                         => CONNECTED_TO_user_dipsw_external_connection_export,                         --               user_dipsw_external_connection.export
			user_led_external_connection_export                           => CONNECTED_TO_user_led_external_connection_export,                           --                 user_led_external_connection.export
			user_pb_external_connection_export                            => CONNECTED_TO_user_pb_external_connection_export                             --                  user_pb_external_connection.export
		);

